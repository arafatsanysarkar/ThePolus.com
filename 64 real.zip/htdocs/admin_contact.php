<?php include 'includes/db.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Contact Messages</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(120deg, #a1c4fd, #c2e9fb);
            margin: 0;
            padding: 20px;
        }

        h2 {
            text-align: center;
            color: #ffffff;
            background: #2980b9;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }

        .message-box {
            background: #ffffff;
            border-left: 6px solid #3498db;
            border-radius: 12px;
            padding: 25px;
            margin: 20px auto;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            max-width: 800px;
            transition: transform 0.2s ease;
        }

        .message-box:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 18px rgba(0,0,0,0.2);
        }

        .message-box p {
            margin: 8px 0;
            font-size: 16px;
            line-height: 1.6;
            color: #333;
        }

        .message-box p strong {
            color: #2c3e50;
        }

        .timestamp {
            color: #7f8c8d;
            font-size: 13px;
            margin-top: 10px;
        }

        @media (max-width: 600px) {
            .message-box {
                padding: 20px;
                margin: 15px;
            }
            h2 {
                font-size: 20px;
                padding: 10px;
            }
        }
    </style>
</head>
<body>

<h2>📨 Contact Messages</h2>

<?php
$query = "SELECT * FROM contact_messages ORDER BY id DESC";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) === 0) {
    echo "<p style='text-align:center; color:white;'>No messages found.</p>";
} else {
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<div class='message-box'>";
        echo "<p><strong>👤 Name:</strong> " . htmlspecialchars($row['name']) . "</p>";
        echo "<p><strong>📧 Email:</strong> " . htmlspecialchars($row['email']) . "</p>";
        echo "<p><strong>💬 Message:</strong><br>" . nl2br(htmlspecialchars($row['message'])) . "</p>";
        echo "<p class='timestamp'>📅 Received on: " . $row['created_at'] . "</p>";
        echo "</div>";
    }
}
?>

</body>
</html>
