<?php 
session_start();
include 'includes/db.php';

if (!isset($_SESSION['cart']) || count($_SESSION['cart']) == 0) {
    echo "<h2 style='text-align:center; padding: 50px;'>Your cart is empty.</h2>";
    exit;
}

$cart_ids = array_map(fn($item) => $item['id'], $_SESSION['cart']);
$cart_items_str = implode(",", array_map('intval', $cart_ids));
$query = "SELECT * FROM products WHERE id IN ($cart_items_str)";
$result = $conn->query($query);

$products = [];
while ($row = $result->fetch_assoc()) {
    $products[$row['id']] = $row;
}

$order_success = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['name']) && isset($_POST['phone']) && isset($_POST['address'])) {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'] ?? '';
    $address = $_POST['address'];
    $location = $_POST['location'] ?? '';

    $total_price = 0;
    foreach ($_SESSION['cart'] as $item) {
        $product = $products[$item['id']];
        $quantity = $item['quantity'];
        $total_price += $product['price'] * $quantity;
    }

    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 1000;

$stmt = $conn->prepare("INSERT INTO orders (user_id, name, phone, email, address, location, total_price) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("isssssd", $user_id, $name, $phone, $email, $address, $location, $total_price);

    $stmt->execute();
    $order_id = $stmt->insert_id;
    $stmt->close();

    $stmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, size, price) VALUES (?, ?, ?, ?, ?)");
    foreach ($_SESSION['cart'] as $item) {
        $product_id = $item['id'];
        $quantity = $item['quantity'];
        $size = $item['size'];
        $price = $products[$product_id]['price'];
        $stmt->bind_param("iiisd", $order_id, $product_id, $quantity, $size, $price);
        $stmt->execute();
    }
    $stmt->close();

    $order_success = true;
    unset($_SESSION['cart']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Confirm Order</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f0f2f5;
            margin: 0;
            padding: 0;
        }
        
        h1 {
            text-align: center;
            margin-top: 20px;
            color: #2c3e50;
        }
        .form-container {
            max-width: 600px;
            margin: 30px auto;
            background: #fff;
            padding: 25px 30px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .form-container input, textarea {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 16px;
        }
        .form-container button {
            background: linear-gradient(135deg, #27ae60, #2ecc71);
            color: white;
            border: none;
            padding: 14px 30px;
            border-radius: 10px;
            font-size: 16px;
            cursor: pointer;
            margin-bottom: 10px;
            width: 100%;
        }
        .form-container button:hover {
            background: linear-gradient(135deg, #219150, #27ae60);
        }
        .location {
            background: #f9f9f9;
            padding: 10px 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            font-size: 15px;
        }
        .success-message {
            text-align: center;
            padding: 20px;
            background-color: #dff0d8;
            color: #27ae60;
            font-size: 20px;
            font-weight: bold;
            border-radius: 10px;
            width: fit-content;
            margin: 20px auto;
        }
        .summary-box {
            text-align: center;
            margin-top: 20px;
            font-size: 18px;
            font-weight: bold;
        }
        .view-cart-box {
            display: none;
            margin-top: 30px;
        }
        .cart-item {
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 10px;
            margin-bottom: 15px;
            padding: 15px;
            display: flex;
            flex-direction: row;
            align-items: center;
            gap: 15px;
        }
        .cart-item img {
            max-width: 100px;
            height: auto;
            border-radius: 10px;
        }
        .cart-item-details {
            flex: 1;
        }

        /* Responsive Style */
        @media (max-width: 768px) {
            .form-container {
                width: 90%;
                padding: 20px;
            }

            nav a {
                display: block;
                margin: 10px 0;
            }

            .cart-item {
                flex-direction: column;
                text-align: center;
            }

            .cart-item img {
                margin: 0 auto 10px;
            }

            .summary-box {
                font-size: 16px;
            }
        }
    </style>
    <script>
        function getLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                    const lat = position.coords.latitude;
                    const lon = position.coords.longitude;
                    const loc = "Latitude: " + lat + ", Longitude: " + lon;
                    document.getElementById("location-display").innerText = loc;
                    document.getElementById("location-input").value = loc;
                }, function() {
                    document.getElementById("location-display").innerText = "Location permission denied.";
                });
            } else {
                document.getElementById("location-display").innerText = "Geolocation is not supported.";
            }
        }

        function toggleCartItems() {
            var box = document.getElementById("view-cart-box");
            box.style.display = (box.style.display === "none") ? "block" : "none";
        }
    </script>
</head>
<body>


<h1>🧾 Confirm Your Order</h1>

<?php if ($order_success): ?>
    <div class="success-message">🎉 Order placed successfully!</div>
<?php else: ?>
<div class="form-container">
    <form method="POST">
        <input type="text" name="name" placeholder="Your Name" required>
        <input type="tel" name="phone" placeholder="Mobile Number" pattern="01[0-9]{9}" required title="মোবাইল নম্বর দিন (যেমন: 01XXXXXXXXX)">
        <input type="email" name="email" placeholder="Email (Optional)">
        <textarea name="address" placeholder="Address" rows="3" required></textarea>

        <input type="hidden" name="location" id="location-input">

        <div class="location">
            <strong>📍 Current Location:</strong>
            <div id="location-display">Click "Get Location" button</div>
            <button type="button" onclick="getLocation()">Get Location</button>
        </div>

        <div class="summary-box">
            <?php 
                $total_price = 0;
                $total_items = 0;
                foreach ($_SESSION['cart'] as $item) {
                    $product = $products[$item['id']];
                    $quantity = $item['quantity'];
                    $total_price += $product['price'] * $quantity;
                    $total_items += $quantity;
                }
            ?>
            🧾 Total Price: $<?php echo number_format($total_price, 2); ?> |
            🧺 Total Items: <?php echo $total_items; ?>
        </div>

        <br>
        <button type="submit">✅ Confirm Order</button>
        <button type="button" onclick="toggleCartItems()">🛒 View Cart Items</button>
    </form>
</div>

<div class="form-container view-cart-box" id="view-cart-box">
    <?php foreach ($_SESSION['cart'] as $item): 
        $product = $products[$item['id']];
    ?>
        <div class="cart-item">
            <img src="uploads/<?php echo htmlspecialchars($product['image']); ?>" alt="">
            <div class="cart-item-details">
                <strong><?php echo htmlspecialchars($product['title']); ?></strong><br>
                Price: $<?php echo htmlspecialchars($product['price']); ?><br>
                Quantity: <?php echo htmlspecialchars($item['quantity']); ?><br>
                Size: <?php echo htmlspecialchars($item['size']); ?>
            </div>
        </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

</body>
</html>  