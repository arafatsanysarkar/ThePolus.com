<?php
session_start();
session_unset();   // সব সেশন ভ্যালু মুছে ফেলা
session_destroy(); // পুরো সেশন ধ্বংস করা
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout</title>

    <!-- SweetAlert2 & Animate.css -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
</head>
<body>

<script>
Swal.fire({
    title: '👋 Logged Out!',
    text: 'You have been successfully logged out.',
    icon: 'success',
    showClass: {
        popup: 'animate__animated animate__fadeInDown'
    },
    hideClass: {
        popup: 'animate__animated animate__fadeOutUp'
    },
    confirmButtonColor: '#4CAF50',
    background: window.matchMedia('(prefers-color-scheme: dark)').matches ? '#1e1e2f' : '#fff',
    color: window.matchMedia('(prefers-color-scheme: dark)').matches ? '#ccc' : '#000',
    timer: 2000,
    timerProgressBar: true,
    showConfirmButton: false
}).then(() => {
    window.location.href = 'index.php'; // লগআউট হওয়ার পর যেখানে পাঠাতে চাও
});
</script>

</body>
</html>
