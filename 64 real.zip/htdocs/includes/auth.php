<?php
session_start();

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isSeller() {
    // সেলার চেক করার জন্য যদি আপনার ডাটাবেসে সেলার টাইপের ফিল্ড থাকে, সেটি ব্যবহার করতে পারেন।
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'seller';
}
?>
