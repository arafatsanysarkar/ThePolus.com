
<?php
$host = "sql302.infinityfree.com";
$user = "if0_38351022";
$password = "GDKC6n4pq4S4caC";
$dbname = "if0_38351022_ecommerce_website";

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>


