<?php
session_start();
include '../includes/db.php';

// Count total items in cart
$_SESSION['cart_count'] = 0;
foreach ($_SESSION['cart'] as $item) {
    $_SESSION['cart_count'] += $item['quantity'];
}

// সেলার চেক করা, যদি সেলার না হয় তবে রিডিরেক্ট করা
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'customer') {
    header('Location: ../login.php');
    exit;
}

$seller_id = $_SESSION['user_id'];

// ইউজারের নাম এবং ইমেইল নেয়ার জন্য ডেটাবেজ থেকে তথ্য নেয়া
$query = "SELECT name, email FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $seller_id);
$stmt->execute();
$stmt->bind_result($seller_name, $seller_email); // name এবং email দুটি ফিল্ড bind করা হচ্ছে
$stmt->fetch();
$stmt->close();

// সেলারের প্রোডাক্টগুলো দেখতে
$query = "SELECT * FROM products WHERE seller_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $seller_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Dashboard</title>
    <link rel="stylesheet" href="../assets/navstyles.css">
    <link rel="stylesheet" href="../assets/styles1.css">
</head>
<body>

    <section id="header">
        <a href="#"><img src="../image/logo.png" class="logo" alt=""></a>

        <div>
            <ul id="navbar">
                <li><a href="../index.php">Home</a></li>
                <li><a href="#blog.html">Blog</a></li>
                <li><a href="#about.html">About</a></li>
                <li><a href="#contact.html">Contact</a></li>
                 <li><a class="active" href="dashboard.php">Profile</a></li>
                 
                 <li id="lg-bag">
    <a href="cart.php">
        <i class="cart">🛒</i>
        <?php if (!empty($_SESSION['cart_count'])): ?>
            <span class="cart-badge"><?php echo $_SESSION['cart_count']; ?></span>
        <?php endif; ?>
    </a>
</li>
 
                <a href="#" id="close"><i class="fa-solid fa-xmark"></i></a>  
            </ul>
        </div>

        <div id="mobile">
    <a href="cart.php" class="mobile-cart">
        <i class="cart">🛒</i>
        <?php if (!empty($_SESSION['cart_count'])): ?>
            <span class="cart-badge"><?php echo $_SESSION['cart_count']; ?></span>
        <?php endif; ?>
    </a>
    <i id="bar" class="fas fa-outdent"></i>
</div>

</section>

    <h1>Welcome to Customer Dashboard</h1>

    <!-- User Info -->
<div class="user-info">
    <h3>User Info</h3>
    <p>Name: <?php echo htmlspecialchars($seller_name); ?></p>
    <p>Email: <?php echo htmlspecialchars($seller_email); ?></p>
    <p><a href="../logout.php" class="btn btn-delete" >Logout</a></p>
</div>

<div class="user-info">
    <h3>Saved Products</h3>
    <p><a href="../saved_products.php" class="btn btn-view-orders">View</a></p>
</div>

<div class="user-info">
    <h3>Orders</h3>
    <p><a href="../my_orders.php" class="btn btn-view-orders">Orders I Placed</a></p>
</div>




<script>
let bar = document.getElementById('bar');
let nav = document.getElementById('navbar');
let mobile = document.getElementById('mobile');
let close = document.getElementById('close');

if (bar) {
    bar.addEventListener('click', () => {
        nav.classList.add('active');
        mobile.classList.add('hide'); // মোবাইল cart & bar আইকন হাইড করো
    });
}

if (close) {
    close.addEventListener('click', () => {
        nav.classList.remove('active');
        mobile.classList.remove('hide'); // আবার দেখাও
    });
}

</script>
<script src="https://kit.fontawesome.com/c9847c48a6.js" crossorigin="anonymous"></script>
</body>
</html>
