<?php
session_start();
include('includes/db.php');
include('includes/functions.php');

// লগ ইন না থাকলে রিটার্ন
if (!isLoggedIn()) {
    echo json_encode([
        'success' => false,
        'message' => 'সেভ করতে হলে আপনাকে লগ ইন করতে হবে।'
    ]);
    exit;
}

if (isset($_POST['product_id'])) {
    $user_id = $_SESSION['user_id'];
    $product_id = intval($_POST['product_id']);

    // ডুপ্লিকেট চেক
    $check = $conn->prepare("SELECT * FROM saved_products WHERE user_id = ? AND product_id = ?");
    $check->bind_param("ii", $user_id, $product_id);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        echo json_encode([
            'success' => false,
            'message' => 'এই পণ্যটি আপনি আগেই সেভ করেছেন।'
        ]);
        exit;
    }

    // সেভ করুন
    $stmt = $conn->prepare("INSERT INTO saved_products (user_id, product_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $user_id, $product_id);
    if ($stmt->execute()) {
        echo json_encode([
            'success' => true,
            'message' => 'পণ্যটি সফলভাবে সেভ করা হয়েছে!'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'সেভ করতে সমস্যা হয়েছে।'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'পণ্য আইডি পাওয়া যায়নি।'
    ]);
}
?>
