<?php
session_start();

// Check if the user is already logged in, redirect to homepage if true
if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

include 'includes/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $role = $_POST['role'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Check if email already exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $error_message = "This email is already registered!";
    } else {
        // Prepare and execute the database query to insert the user
        $stmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $email, $password, $role);

        if ($stmt->execute()) {
            $_SESSION['user_id'] = $stmt->insert_id; // Set session for the newly registered user
            $success_message = "Registration successful! Please log in."; // Success message
        } else {
            $error_message = "Error: " . $stmt->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="assets/styles.css">
</head>
<body>

<div class="form-container">
    <h2>Register</h2>
    <?php
    if (isset($error_message)) {
        echo "<script>
            Swal.fire({
                title: 'Error!',
                text: '$error_message',
                icon: 'error',
                confirmButtonColor: '#ff4e4e',
            });
        </script>";
    }

    // Show success message popup after successful registration
    if (isset($success_message)) {
        echo "<script>
            Swal.fire({
                title: 'Success!',
                text: '$success_message',
                icon: 'success',
                confirmButtonColor: '#4CAF50',
            }).then(() => {
                window.location.href = 'login.php'; // Redirect to login page after success
            });
        </script>";
    }
    ?>
    
    <form method="POST">
        <label for="name">Name:</label>
        <input type="text" name="name" id="name" required><br>

        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required><br>

        <label for="role">Role:</label>
        <select name="role" id="role" required>
            <option value="customer">Customer</option>
            
        </select><br>

        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required><br>

        <button type="submit">Register</button>
    </form>

    <p>Already have an account? <a href="login.php">Login here</a></p>
</div>

</body>
</html>
