<?php
session_start();
include '../includes/db.php';

// চেক করা যে ইউজার সেলার কিনা
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'seller') {
    header('Location: ../login.php');
    exit;
}

$seller_id = $_SESSION['user_id'];

// যদি ব্র্যান্ড আপডেট করা হয়
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // ব্র্যান্ড নাম নিতে হবে
    $brand_name = trim($_POST['brand_name']);
    $brand_image = $_FILES['brand_image'];

    // ফাইল আপলোড চেক করা
    if ($brand_image['name']) {
        $image_name = time() . '_' . basename($brand_image['name']);
        $image_path = "../uploads/" . $image_name;

        // ফাইল টাইপ এবং সাইজ চেক
        if (in_array($brand_image['type'], ['image/jpeg', 'image/png', 'image/gif']) && $brand_image['size'] < 5000000) {
            if (move_uploaded_file($brand_image['tmp_name'], $image_path)) {
                $query = "UPDATE users SET brand_name = ?, brand_image = ? WHERE id = ?";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("ssi", $brand_name, $image_name, $seller_id);
                if ($stmt->execute()) {
                    header('Location: dashboard.php');
                    exit;
                } else {
                    echo "Error updating brand details.";
                }
            } else {
                echo "Error uploading file.";
            }
        } else {
            echo "Invalid file type or size.";
        }
    } else {
        // যদি শুধুমাত্র নাম আপডেট করা হয়
        $query = "UPDATE users SET brand_name = ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("si", $brand_name, $seller_id);
        if ($stmt->execute()) {
            header('Location: dashboard.php');
            exit;
        } else {
            echo "Error updating brand name.";
        }
    }
}
?>
