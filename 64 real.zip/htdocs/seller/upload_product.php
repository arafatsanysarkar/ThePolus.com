<?php
include '../includes/db.php';
include '../includes/auth.php';

if (!isLoggedIn() || !isSeller()) {
    die("Access Denied. You must be logged in as a seller.");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $desc = $_POST['description'];
    $price = $_POST['price'];

    $mainImage = $_FILES['image']['name'];
    $target = "../uploads/" . basename($mainImage);

    $otherImages = [];
    for ($i = 1; $i <= 10; $i++) {
        if (isset($_FILES["image$i"]) && $_FILES["image$i"]['error'] == 0) {
            $otherImageName = $_FILES["image$i"]['name'];
            $otherTarget = "../uploads/" . basename($otherImageName);
            if (move_uploaded_file($_FILES["image$i"]['tmp_name'], $otherTarget)) {
                $otherImages[] = $otherImageName;
            }
        }
    }

    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
        $otherImagesJson = json_encode($otherImages);

        $stmt = $conn->prepare("INSERT INTO products (seller_id, title, description, price, image, other_images) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("issdss", $_SESSION['user_id'], $title, $desc, $price, $mainImage, $otherImagesJson);

        if ($stmt->execute()) {
            echo "<script>alert('Product uploaded successfully.'); location.href='dashboard.php';</script>";
        } else {
            echo "Error: " . $stmt->error;
        }
    } else {
        echo "Main image upload failed.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Upload Product</title>
  <link rel="stylesheet" href="../assets/navstyles.css">
  <style>
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Spartan', sans-serif;
    }


    body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f5f7fa;
    color: #333;
    line-height: 1.6;
}

    .container {
      display: flex;
      flex-direction: column;
      background-color: #fff;
      border-radius: 10px;
      padding: 30px;
      max-width: 100%;
      margin: 0 auto;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      box-sizing: border-box;
    }

    .form-left,
    .form-right {
      width: 100%;
      padding: 15px;
      box-sizing: border-box;
    }

    @media (min-width: 768px) {
      .container {
        flex-direction: row;
      }

      .form-left,
      .form-right {
        width: 50%;
      }
    }

    /* Image preview area */
    .main-image {
      width: 100%;
      height: 250px;
      border-radius: 10px;
      background-color: #eee;
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
      margin-bottom: 15px;
      cursor: pointer;
      border: 2px dashed #ccc;
    }

    .main-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }

    .main-image span {
      color: #aaa;
      font-size: 20px;
    }

    /* Thumbnail images */
    .thumbs {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 15px;
      justify-content: flex-start;
    }

    .thumb-box {
      width: 100%;
      height: 80px;
      background-color: #eee;
      border-radius: 5px;
      overflow: hidden;
      border: 1px dashed #ccc;
      position: relative;
      cursor: pointer;
    }

    .thumb-box img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }

    .thumb-box span {
      position: absolute;
      top: 25%;
      left: 25%;
      color: #999;
      font-size: 25px;
    }

    /* Input fields */
    .form-right input,
    .form-right textarea {
      width: 100%;
      padding: 15px;
      margin-top: 10px;
      margin-bottom: 20px;
      border-radius: 8px;
      border: 1px solid #ccc;
      font-size: 18px;
      box-sizing: border-box;
    }

    .form-right label {
      font-weight: bold;
      font-size: 18px;
    }

    /* Button */
    .submit-btn {
      margin-top: 20px;
      width: 100%;
      padding: 18px;
      background-color: #3498db;
      color: #fff;
      font-size: 20px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    .submit-btn:hover {
      background-color: #2980b9;
    }

    /* Mobile specific adjustments */
    @media (max-width: 576px) {
      .main-image {
        height: 220px;
      }

      .thumb-box {
        width: 100%;
        height: 100px;
      }

      .form-left,
      .form-right {
        width: 100%;
      }

      .submit-btn {
        padding: 15px;
        font-size: 18px;
      }

      .form-right input,
      .form-right textarea {
        font-size: 18px;
      }

      .form-right label {
        font-size: 18px;
      }

      .container {
        padding: 20px;
      }

      .thumbs {
        grid-template-columns: repeat(3, 1fr);
      }
    }
  </style>
</head>
<body>

<section id="header">
        <a href="#"><img src="../image/logo.png" class="logo" alt=""></a>

        <div>
            <ul id="navbar">
                <li><a href="../index.php">Home</a></li>
                <li><a href="#shop.php">Shop</a></li>
                <li><a href="#about.php">About</a></li>
                <li><a href="#">Contact</a></li>
                <li><a href="dashboard.php">Profile</a></li>
                <li><a class="active" href="#upload_product.php">+ Add New Product</a></li>
                
                 
                 
                <a href="#" id="close"><i class="fa-solid fa-xmark"></i></a>  
            </ul>
        </div>

        <div id="mobile">
            
            <i id="bar" class="fas fa-outdent"></i>
        </div>
    </section>

<form class="container" method="POST" enctype="multipart/form-data">
  <!-- Left: Image Upload -->
  <div class="form-left">
    <label>Main Image</label>
    <div class="main-image" onclick="document.getElementById('mainImageInput').click();">
      <span id="mainImageText">Click to select main image</span>
      <img id="mainImagePreview" />
    </div>
    <input type="file" id="mainImageInput" name="image" accept="image/*" required style="display:none;" onchange="previewMainImage(event)" />

    <label>Other Images</label>
    <div class="thumbs">
      <?php for ($i = 1; $i <= 10; $i++): ?>
        <div class="thumb-box" onclick="document.getElementById('image<?= $i ?>').click();">
          <span id="thumbText<?= $i ?>">+</span>
          <img id="thumbPreview<?= $i ?>" />
        </div>
        <input type="file" name="image<?= $i ?>" id="image<?= $i ?>" accept="image/*" style="display:none;" onchange="previewThumb(event, <?= $i ?>)" />
      <?php endfor; ?>
    </div>
  </div>

  <!-- Right: Product Info -->
  <div class="form-right">
    <label for="title">Product Title</label>
    <input type="text" name="title" id="title" required>

    <label for="description">Description</label>
    <textarea name="description" id="description" rows="10" style="height: 200px; width: 100%;" required></textarea>

    <label for="price">Price (BDT)</label>
    <input type="number" step="0.01" name="price" id="price" required>

    <button class="submit-btn" type="submit">Upload Product</button>
  </div>
</form>

<script>


const bar = document.getElementById('bar')
const close = document.getElementById('close')
const navbar = document.getElementById('navbar')


if (bar) {
    bar.addEventListener('click', () => {
        navbar.classList.add('active');
    })
}

if (close) {
    close.addEventListener('click', () => {
        navbar.classList.remove('active');
    })
}


  function previewMainImage(event) {
    const input = event.target;
    const preview = document.getElementById("mainImagePreview");
    const text = document.getElementById("mainImageText");

    if (input.files && input.files[0]) {
      const reader = new FileReader();
      reader.onload = function(e) {
        preview.src = e.target.result;
        preview.style.display = "block";
        text.style.display = "none";
      };
      reader.readAsDataURL(input.files[0]);
    }
  }

  function previewThumb(event, index) {
    const input = event.target;
    const preview = document.getElementById(`thumbPreview${index}`);
    const text = document.getElementById(`thumbText${index}`);

    if (input.files && input.files[0]) {
      const reader = new FileReader();
      reader.onload = function(e) {
        preview.src = e.target.result;
        preview.style.display = "block";
        text.style.display = "none";
      };
      reader.readAsDataURL(input.files[0]);
    }
  }
</script>

<script src="https://kit.fontawesome.com/c9847c48a6.js" crossorigin="anonymous"></script>

</body>
</html>
<?php
include '../includes/db.php';
include '../includes/auth.php';

if (!isLoggedIn() || !isSeller()) {
    die("Access Denied. You must be logged in as a seller.");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $desc = $_POST['description'];
    $price = $_POST['price'];

    $mainImage = $_FILES['image']['name'];
    $target = "../uploads/" . basename($mainImage);

    $otherImages = [];
    for ($i = 1; $i <= 10; $i++) {
        if (isset($_FILES["image$i"]) && $_FILES["image$i"]['error'] == 0) {
            $otherImageName = $_FILES["image$i"]['name'];
            $otherTarget = "../uploads/" . basename($otherImageName);
            if (move_uploaded_file($_FILES["image$i"]['tmp_name'], $otherTarget)) {
                $otherImages[] = $otherImageName;
            }
        }
    }

    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
        $otherImagesJson = json_encode($otherImages);

        $stmt = $conn->prepare("INSERT INTO products (seller_id, title, description, price, image, other_images) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("issdss", $_SESSION['user_id'], $title, $desc, $price, $mainImage, $otherImagesJson);

        if ($stmt->execute()) {
            echo "<script>alert('Product uploaded successfully.'); location.href='dashboard.php';</script>";
        } else {
            echo "Error: " . $stmt->error;
        }
    } else {
        echo "Main image upload failed.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Upload Product</title>
  <link rel="stylesheet" href="../assets/navstyles.css">
  <style>
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Spartan', sans-serif;
    }


    body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f5f7fa;
    color: #333;
    line-height: 1.6;
}

    .container {
      display: flex;
      flex-direction: column;
      background-color: #fff;
      border-radius: 10px;
      padding: 30px;
      max-width: 100%;
      margin: 0 auto;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      box-sizing: border-box;
    }

    .form-left,
    .form-right {
      width: 100%;
      padding: 15px;
      box-sizing: border-box;
    }

    @media (min-width: 768px) {
      .container {
        flex-direction: row;
      }

      .form-left,
      .form-right {
        width: 50%;
      }
    }

    /* Image preview area */
    .main-image {
      width: 100%;
      height: 250px;
      border-radius: 10px;
      background-color: #eee;
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
      margin-bottom: 15px;
      cursor: pointer;
      border: 2px dashed #ccc;
    }

    .main-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }

    .main-image span {
      color: #aaa;
      font-size: 20px;
    }

    /* Thumbnail images */
    .thumbs {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 15px;
      justify-content: flex-start;
    }

    .thumb-box {
      width: 100%;
      height: 80px;
      background-color: #eee;
      border-radius: 5px;
      overflow: hidden;
      border: 1px dashed #ccc;
      position: relative;
      cursor: pointer;
    }

    .thumb-box img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }

    .thumb-box span {
      position: absolute;
      top: 25%;
      left: 25%;
      color: #999;
      font-size: 25px;
    }

    /* Input fields */
    .form-right input,
    .form-right textarea {
      width: 100%;
      padding: 15px;
      margin-top: 10px;
      margin-bottom: 20px;
      border-radius: 8px;
      border: 1px solid #ccc;
      font-size: 18px;
      box-sizing: border-box;
    }

    .form-right label {
      font-weight: bold;
      font-size: 18px;
    }

    /* Button */
    .submit-btn {
      margin-top: 20px;
      width: 100%;
      padding: 18px;
      background-color: #3498db;
      color: #fff;
      font-size: 20px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    .submit-btn:hover {
      background-color: #2980b9;
    }

    /* Mobile specific adjustments */
    @media (max-width: 576px) {
      .main-image {
        height: 220px;
      }

      .thumb-box {
        width: 100%;
        height: 100px;
      }

      .form-left,
      .form-right {
        width: 100%;
      }

      .submit-btn {
        padding: 15px;
        font-size: 18px;
      }

      .form-right input,
      .form-right textarea {
        font-size: 18px;
      }

      .form-right label {
        font-size: 18px;
      }

      .container {
        padding: 20px;
      }

      .thumbs {
        grid-template-columns: repeat(3, 1fr);
      }
    }
  </style>
</head>
<body>

<section id="header">
        <a href="#"><img src="https://i.ibb.co.com/zTJC4x5j/logo.png" class="logo" alt=""></a>

        <div>
            <ul id="navbar">
                <li><a href="../index.php">Home</a></li>
                <li><a href="dashboard.php">Profile</a></li>
                <li><a class="active" href="#upload_product.php">+ Add New Product</a></li>
                <li><a href="#">About</a></li>
                 
                 <li id="lg-bag"><a href="cart.html"><i class="fa-solid fa-bag-shopping"></i></a></li> 
                <a href="#" id="close"><i class="fa-solid fa-xmark"></i></a>  
            </ul>
        </div>

        <div id="mobile">
            <a href="cart.html"><i class="fa-solid fa-bag-shopping"></i></a>
            <i id="bar" class="fas fa-outdent"></i>
        </div>
    </section>

<form class="container" method="POST" enctype="multipart/form-data">
  <!-- Left: Image Upload -->
  <div class="form-left">
    <label>Main Image</label>
    <div class="main-image" onclick="document.getElementById('mainImageInput').click();">
      <span id="mainImageText">Click to select main image</span>
      <img id="mainImagePreview" />
    </div>
    <input type="file" id="mainImageInput" name="image" accept="image/*" required style="display:none;" onchange="previewMainImage(event)" />

    <label>Other Images</label>
    <div class="thumbs">
      <?php for ($i = 1; $i <= 10; $i++): ?>
        <div class="thumb-box" onclick="document.getElementById('image<?= $i ?>').click();">
          <span id="thumbText<?= $i ?>">+</span>
          <img id="thumbPreview<?= $i ?>" />
        </div>
        <input type="file" name="image<?= $i ?>" id="image<?= $i ?>" accept="image/*" style="display:none;" onchange="previewThumb(event, <?= $i ?>)" />
      <?php endfor; ?>
    </div>
  </div>

  <!-- Right: Product Info -->
  <div class="form-right">
    <label for="title">Product Title</label>
    <input type="text" name="title" id="title" required>

    <label for="description">Description</label>
    <textarea name="description" id="description" rows="10" style="height: 200px; width: 100%;" required></textarea>

    <label for="price">Price (BDT)</label>
    <input type="number" step="0.01" name="price" id="price" required>

    <button class="submit-btn" type="submit">Upload Product</button>
  </div>
</form>

<script>


const bar = document.getElementById('bar')
const close = document.getElementById('close')
const navbar = document.getElementById('navbar')


if (bar) {
    bar.addEventListener('click', () => {
        navbar.classList.add('active');
    })
}

if (close) {
    close.addEventListener('click', () => {
        navbar.classList.remove('active');
    })
}


  function previewMainImage(event) {
    const input = event.target;
    const preview = document.getElementById("mainImagePreview");
    const text = document.getElementById("mainImageText");

    if (input.files && input.files[0]) {
      const reader = new FileReader();
      reader.onload = function(e) {
        preview.src = e.target.result;
        preview.style.display = "block";
        text.style.display = "none";
      };
      reader.readAsDataURL(input.files[0]);
    }
  }

  function previewThumb(event, index) {
    const input = event.target;
    const preview = document.getElementById(`thumbPreview${index}`);
    const text = document.getElementById(`thumbText${index}`);

    if (input.files && input.files[0]) {
      const reader = new FileReader();
      reader.onload = function(e) {
        preview.src = e.target.result;
        preview.style.display = "block";
        text.style.display = "none";
      };
      reader.readAsDataURL(input.files[0]);
    }
  }
</script>

<script src="https://kit.fontawesome.com/c9847c48a6.js" crossorigin="anonymous"></script>

</body>
</html>
