<?php 
session_start();
include '../includes/db.php';
include '../includes/auth.php';

$seller_id = $_SESSION['user_id'];

$product_query = "SELECT id, title, image FROM products WHERE seller_id = $seller_id";
$product_result = $conn->query($product_query);

$product_map = [];
$product_ids = [];

while ($row = $product_result->fetch_assoc()) {
    $product_map[$row['id']] = [
        'title' => $row['title'],
        'image' => $row['image']
    ];
    $product_ids[] = $row['id'];
}

if (count($product_ids) === 0) {
    echo "<div class='text-center mt-5'><h4>No products found for you.</h4></div>";
    exit;
}

$product_id_str = implode(',', array_map('intval', $product_ids));

$order_items_query = "
    SELECT oi.*, o.name, o.phone, o.address, o.email, o.location, o.total_price, o.id as order_id, o.order_date
    FROM order_items oi
    JOIN orders o ON oi.order_id = o.id
    WHERE oi.product_id IN ($product_id_str)
    ORDER BY o.id DESC
";
$order_items_result = $conn->query($order_items_query);

$orders_by_id = [];

while ($order_row = $order_items_result->fetch_assoc()) {
    $order_id = $order_row['order_id'];

    if (!isset($orders_by_id[$order_id])) {
        $orders_by_id[$order_id]['buyer'] = [
            'name' => $order_row['name'],
            'phone' => $order_row['phone'],
            'email' => $order_row['email'],
            'address' => $order_row['address'],
            'location' => $order_row['location'],
            'total_price' => $order_row['total_price'],
            'order_date' => $order_row['order_date']
        ];
        $orders_by_id[$order_id]['items'] = [];
    }

    $orders_by_id[$order_id]['items'][] = $order_row;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Seller Orders</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .back-button {
            position: fixed;
            top: 30px;
            left: 75px;
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 15px;
            text-decoration: none;
            background-color: black;
            color: white;
            border-radius: 30px;
            font-size: 16px;
            z-index: 999;
            transition: background-color 0.3s ease;
        }

        .back-button img {
            width: 20px;
            height: 20px;
        }

        .back-button:hover {
            background-color: #2980b9;
        }

        @media (max-width: 576px) {
            .table td, .table th {
                font-size: 13px;
                padding: 8px;
            }

            .back-button {
                left: 20px;
                top: 510px;
                right: auto;
            }

            .product-img {
                width: 40px;
                height: 40px;
            }
        }

        .product-img {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 5px;
            margin-right: 8px;
        }
    </style>
</head>
<body class="bg-light">

<a href="dashboard.php" class="back-button">
    <img src="https://img.icons8.com/ios-filled/50/ffffff/left.png" alt="Back" />
    <span></span>
</a>

<div class="container py-4">
    <h2 class="text-center mb-4">📦 Your Product Orders</h2>

    <?php if (count($orders_by_id) > 0): ?>
        <?php foreach ($orders_by_id as $order_id => $order_data): 
            $product_names = array_map(function($item) use ($product_map) {
                return $product_map[$item['product_id']]['title'] ?? 'Unknown';
            }, $order_data['items']);

            $formatted_date = date("M d, Y", strtotime($order_data['buyer']['order_date']));
        ?>
            <div class="card mb-3">
                <div class="card-header d-flex justify-content-between align-items-center" data-bs-toggle="collapse" href="#details-<?php echo $order_id; ?>" role="button" aria-expanded="false" aria-controls="details-<?php echo $order_id; ?>">
                    <div>
                        🧾 <strong>Order #<?php echo $order_id; ?></strong><br>
                        🛍️ <?php echo implode(', ', $product_names); ?>
                    </div>
                    <span class="text-muted small"><?php echo $formatted_date; ?></span>
                </div>
                <div class="collapse card-body" id="details-<?php echo $order_id; ?>">
                    <p><strong>Buyer:</strong> <?php echo htmlspecialchars($order_data['buyer']['name']); ?></p>
                    <p><strong>Phone:</strong> <?php echo htmlspecialchars($order_data['buyer']['phone']); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($order_data['buyer']['email']); ?></p>
                    <p><strong>Address:</strong> <?php echo htmlspecialchars($order_data['buyer']['address']); ?></p>
                    <p><strong>Location:</strong> 
                        <a href="https://www.google.com/maps?q=<?php echo urlencode($order_data['buyer']['location']); ?>" target="_blank">
                            <?php echo htmlspecialchars($order_data['buyer']['location']); ?>
                        </a>
                    </p>

                    <div class="table-responsive mt-3">
                        <table class="table table-bordered table-striped text-nowrap">
                            <thead class="table-primary">
                                <tr>
                                    <th>Product</th>
                                    <th>Size</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                    <th>Subtotal</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($order_data['items'] as $item): 
                                    $subtotal = $item['price'] * $item['quantity'];
                                    $product_id = $item['product_id'];
                                    $product_info = $product_map[$product_id] ?? ['title' => 'Unknown', 'image' => ''];
                                    $product_name = $product_info['title'];
                                    $product_image = $product_info['image'];
                                ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <img src="../uploads/<?php echo htmlspecialchars($product_image); ?>" alt="Image" class="product-img">
                                                <?php echo htmlspecialchars($product_name); ?>
                                            </div>
                                        </td>
                                        <td><?php echo htmlspecialchars($item['size']); ?></td>
                                        <td><?php echo $item['quantity']; ?></td>
                                        <td>$<?php echo number_format($item['price'], 2); ?></td>
                                        <td>$<?php echo number_format($subtotal, 2); ?></td>
                                        <td>
                                            <a href="../product.php?id=<?php echo $product_id; ?>" class="btn btn-primary btn-sm">View Product</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <p class="text-end fw-bold">Total Price: $<?php echo number_format($order_data['buyer']['total_price'], 2); ?></p>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="text-center mt-5">
            <p class="text-muted">😕 No orders placed yet.</p>
        </div>
    <?php endif; ?>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
