<?php
session_start();
include '../includes/db.php';

// সেলার চেক করা, যদি সেলার না হয় তবে রিডিরেক্ট করা
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'seller') {
    header('Location: ../login.php');
    exit;
}

$seller_id = $_SESSION['user_id'];

// পণ্যের আইডি চেক করা
if (isset($_GET['id'])) {
    $product_id = $_GET['id'];
    
    // প্রথমে, নিশ্চিত হওয়া উচিত যে পণ্যটি এই সেলারই আপলোড করেছেন
    $query = "SELECT * FROM products WHERE id = ? AND seller_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $product_id, $seller_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // পণ্য মুছে ফেলা
        $deleteQuery = "DELETE FROM products WHERE id = ? AND seller_id = ?";
        $deleteStmt = $conn->prepare($deleteQuery);
        $deleteStmt->bind_param("ii", $product_id, $seller_id);
        
        if ($deleteStmt->execute()) {
            echo "Product deleted successfully.";
            header('Location: dashboard.php'); // সেলার ড্যাশবোর্ডে ফিরে যাওয়া
            exit;
        } else {
            echo "Error: " . $deleteStmt->error;
        }
    } else {
        echo "Product not found or you don't have permission to delete it.";
    }
} else {
    echo "No product ID provided.";
}
?>
<?php
session_start();
include '../includes/db.php';

// সেলার চেক করা, যদি সেলার না হয় তবে রিডিরেক্ট করা
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'seller') {
    header('Location: ../login.php');
    exit;
}

$seller_id = $_SESSION['user_id'];

// পণ্যের আইডি চেক করা
if (isset($_GET['id'])) {
    $product_id = $_GET['id'];
    
    // প্রথমে, নিশ্চিত হওয়া উচিত যে পণ্যটি এই সেলারই আপলোড করেছেন
    $query = "SELECT * FROM products WHERE id = ? AND seller_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $product_id, $seller_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // পণ্য মুছে ফেলা
        $deleteQuery = "DELETE FROM products WHERE id = ? AND seller_id = ?";
        $deleteStmt = $conn->prepare($deleteQuery);
        $deleteStmt->bind_param("ii", $product_id, $seller_id);
        
        if ($deleteStmt->execute()) {
            echo "Product deleted successfully.";
            header('Location: dashboard.php'); // সেলার ড্যাশবোর্ডে ফিরে যাওয়া
            exit;
        } else {
            echo "Error: " . $deleteStmt->error;
        }
    } else {
        echo "Product not found or you don't have permission to delete it.";
    }
} else {
    echo "No product ID provided.";
}
?>
