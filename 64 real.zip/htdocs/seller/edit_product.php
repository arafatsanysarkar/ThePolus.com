<?php
include '../includes/db.php';
include '../includes/auth.php';

// Count total items in cart
$_SESSION['cart_count'] = 0;
foreach ($_SESSION['cart'] as $item) {
    $_SESSION['cart_count'] += $item['quantity'];
}

if (!isLoggedIn() || !isSeller()) {
    die("Access Denied. You must be logged in as a seller.");
}

if (!isset($_GET['id'])) {
    die("No product ID provided.");
}

$product_id = $_GET['id'];

$stmt = $conn->prepare("SELECT * FROM products WHERE id = ? AND seller_id = ?");
$stmt->bind_param("ii", $product_id, $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
$product = $result->fetch_assoc();

if (!$product) {
    die("Product not found.");
}

$otherImages = json_decode($product['other_images'], true);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $desc = $_POST['description'];
    $price = $_POST['price'];

    // Handle Main Image
    $mainImage = $product['image'];
    if (!empty($_FILES['image']['name'])) {
        $mainImage = $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], "../uploads/" . $mainImage);
    }

    // Handle Other Images
    $updatedOtherImages = $otherImages;
    for ($i = 0; $i < 10; $i++) {
        if (isset($_FILES["image" . ($i)]) && $_FILES["image" . ($i)]['error'] == 0) {
            $otherImageName = $_FILES["image" . ($i)]['name'];
            $otherTarget = "../uploads/" . basename($otherImageName);
            if (move_uploaded_file($_FILES["image" . ($i)]['tmp_name'], $otherTarget)) {
                $updatedOtherImages[$i] = $otherImageName;
            }
        }
    }

    $updatedOtherImagesJson = json_encode($updatedOtherImages);

    $stmt = $conn->prepare("UPDATE products SET title = ?, description = ?, price = ?, image = ?, other_images = ? WHERE id = ? AND seller_id = ?");
    $stmt->bind_param("ssdssii", $title, $desc, $price, $mainImage, $updatedOtherImagesJson, $product_id, $_SESSION['user_id']);

    if ($stmt->execute()) {
        echo "<script>alert('Product updated successfully.'); location.href='dashboard.php';</script>";
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Edit Product</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="../assets/navstyles.css">
  <style>
    

    .back-button {
  position: fixed;
  top: 100px;
  left: 20px;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 15px;
  text-decoration: none;
  background-color: black;
  color: white;
  border-radius: 30px;
  font-size: 16px;
  z-index: 999;
  transition: background-color 0.3s ease;
}


    .back-button img {
      width: 20px;
      height: 20px;
    }

    .back-button:hover {
      background-color: #2980b9;
    }

    .container {
      display: flex;
      flex-wrap: wrap;
      background-color: #fff;
      border-radius: 10px;
      padding: 20px;
      max-width: 1000px;
      margin: auto;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    .form-left, .form-right {
      flex: 1;
      min-width: 300px;
      padding: 15px;
    }

    .main-image {
      width: 100%;
      height: 250px;
      border-radius: 10px;
      background-color: #eee;
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
      margin-bottom: 15px;
      cursor: pointer;
      border: 2px dashed #ccc;
      position: relative;
    }

    .main-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }

    .main-image .edit-icon {
      position: absolute;
      top: 10px;
      right: 10px;
      background-color: rgba(0, 0, 0, 0.6);
      color: #fff;
      padding: 6px 9px;
      border-radius: 50%;
      cursor: pointer;
    }

    .thumbs {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
    }

    .thumb-box {
      width: 80px;
      height: 80px;
      background-color: #eee;
      border-radius: 6px;
      overflow: hidden;
      border: 1px dashed #ccc;
      position: relative;
      cursor: pointer;
    }

    .thumb-box img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .thumb-box .edit-icon {
      position: absolute;
      top: 5px;
      right: 5px;
      background-color: rgba(0, 0, 0, 0.6);
      color: #fff;
      padding: 4px 6px;
      border-radius: 50%;
      font-size: 12px;
    }

    .form-right input, .form-right textarea {
      width: 100%;
      padding: 10px;
      margin-top: 10px;
      margin-bottom: 20px;
      border-radius: 5px;
      border: 1px solid #ccc;
      font-size: 16px;
    }

    .form-right label {
      font-weight: bold;
    }

    .submit-btn {
      margin-top: 20px;
      width: 100%;
      padding: 14px;
      background-color: #3498db;
      color: #fff;
      font-size: 18px;
      border: none;
      border-radius: 6px;
      cursor: pointer;
    }

    .submit-btn:hover {
      background-color: #2980b9;
    }

    @media(max-width: 768px) {
      .form-left, .form-right {
        min-width: 100%;
      }

      .back-button {
          left: auto;
          top: 72px;
          right: 20px;
  }

    }
  </style>
</head>
<body>



<!-- ✅ Header -->
<section id="header">
        <a href="#"><img src="../image/logo.png" class="logo" alt=""></a>

        <div>
            <ul id="navbar">
                <li><a href="../index.php">Home</a></li>
                <li><a href="#shop.php">Shop</a></li>
                <li><a href="#about.php">About</a></li>
                <li><a href="#">Contact</a></li>
                <li><a href="dashboard.php">Profile</a></li>
                <li><a class="active" href="#upload_product.php">✏️ Edit product</a></li>
                
                 
                 
                <a href="#" id="close"><i class="fa-solid fa-xmark"></i></a>  
            </ul>
        </div>

        <div id="mobile">
            
            <i id="bar" class="fas fa-outdent"></i>
        </div>
    </section>


<!-- ✅ Form -->
<section >
  <form class="container" method="POST" enctype="multipart/form-data">
    <div class="form-left">
      <label>Main Image</label>
      <div class="main-image" onclick="document.getElementById('mainImageInput').click();">
        <img id="mainImagePreview" src="../uploads/<?php echo htmlspecialchars($product['image']); ?>" />
        <div class="edit-icon">✏️</div>
      </div>
      <input type="file" id="mainImageInput" name="image" accept="image/*" style="display:none;" onchange="previewMainImage(event)" />

      <label>Other Images</label>
      <div class="thumbs">
        <?php
          for ($i = 0; $i < 10; $i++):
            $img = isset($otherImages[$i]) ? $otherImages[$i] : '';
        ?>
          <div class="thumb-box" onclick="document.getElementById('image<?php echo $i; ?>').click();">
            <?php if ($img): ?>
              <img id="thumbPreview<?php echo $i; ?>" src="../uploads/<?php echo htmlspecialchars($img); ?>" />
            <?php else: ?>
              <img id="thumbPreview<?php echo $i; ?>" src="https://via.placeholder.com/80" />
            <?php endif; ?>
            <div class="edit-icon">✏️</div>
          </div>
          <input type="file" name="image<?php echo $i; ?>" id="image<?php echo $i; ?>" accept="image/*" style="display:none;" onchange="previewThumb(event, <?php echo $i; ?>)" />
        <?php endfor; ?>
      </div>
    </div>

    <div class="form-right">
      <label for="title">Product Title</label>
      <input type="text" name="title" id="title" value="<?php echo htmlspecialchars($product['title']); ?>" required>

      <label for="description">Description</label>
      <textarea name="description" id="description" rows="10" required><?php echo htmlspecialchars($product['description']); ?></textarea>

      <label for="price">Price (BDT)</label>
      <input type="number" step="0.01" name="price" id="price" value="<?php echo htmlspecialchars($product['price']); ?>" required>

      <button class="submit-btn" type="submit">Update Product</button>
    </div>
  </form>
</section>

<script>
  let bar = document.getElementById('bar');
let nav = document.getElementById('navbar');
let mobile = document.getElementById('mobile');
let close = document.getElementById('close');

if (bar) {
    bar.addEventListener('click', () => {
        nav.classList.add('active');
        mobile.classList.add('hide'); // মোবাইল cart & bar আইকন হাইড করো
    });
}

if (close) {
    close.addEventListener('click', () => {
        nav.classList.remove('active');
        mobile.classList.remove('hide'); // আবার দেখাও
    });
}

  function previewMainImage(event) {
    const reader = new FileReader();
    reader.onload = function () {
      document.getElementById('mainImagePreview').src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  }

  function previewThumb(event, index) {
    const reader = new FileReader();
    reader.onload = function () {
      document.getElementById('thumbPreview' + index).src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  }
</script>

<script src="https://kit.fontawesome.com/c9847c48a6.js" crossorigin="anonymous"></script>
</body>
</html>
<?php
include '../includes/db.php';
include '../includes/auth.php';

// Count total items in cart
$_SESSION['cart_count'] = 0;
foreach ($_SESSION['cart'] as $item) {
    $_SESSION['cart_count'] += $item['quantity'];
}

if (!isLoggedIn() || !isSeller()) {
    die("Access Denied. You must be logged in as a seller.");
}

if (!isset($_GET['id'])) {
    die("No product ID provided.");
}

$product_id = $_GET['id'];

$stmt = $conn->prepare("SELECT * FROM products WHERE id = ? AND seller_id = ?");
$stmt->bind_param("ii", $product_id, $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
$product = $result->fetch_assoc();

if (!$product) {
    die("Product not found.");
}

$otherImages = json_decode($product['other_images'], true);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $desc = $_POST['description'];
    $price = $_POST['price'];

    // Handle Main Image
    $mainImage = $product['image'];
    if (!empty($_FILES['image']['name'])) {
        $mainImage = $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], "../uploads/" . $mainImage);
    }

    // Handle Other Images
    $updatedOtherImages = $otherImages;
    for ($i = 0; $i < 10; $i++) {
        if (isset($_FILES["image" . ($i)]) && $_FILES["image" . ($i)]['error'] == 0) {
            $otherImageName = $_FILES["image" . ($i)]['name'];
            $otherTarget = "../uploads/" . basename($otherImageName);
            if (move_uploaded_file($_FILES["image" . ($i)]['tmp_name'], $otherTarget)) {
                $updatedOtherImages[$i] = $otherImageName;
            }
        }
    }

    $updatedOtherImagesJson = json_encode($updatedOtherImages);

    $stmt = $conn->prepare("UPDATE products SET title = ?, description = ?, price = ?, image = ?, other_images = ? WHERE id = ? AND seller_id = ?");
    $stmt->bind_param("ssdssii", $title, $desc, $price, $mainImage, $updatedOtherImagesJson, $product_id, $_SESSION['user_id']);

    if ($stmt->execute()) {
        echo "<script>alert('Product updated successfully.'); location.href='dashboard.php';</script>";
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Edit Product</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="../assets/navstyles.css">
  <style>
    

    .back-button {
  position: fixed;
  top: 100px;
  left: 20px;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 15px;
  text-decoration: none;
  background-color: black;
  color: white;
  border-radius: 30px;
  font-size: 16px;
  z-index: 999;
  transition: background-color 0.3s ease;
}


    .back-button img {
      width: 20px;
      height: 20px;
    }

    .back-button:hover {
      background-color: #2980b9;
    }

    .container {
      display: flex;
      flex-wrap: wrap;
      background-color: #fff;
      border-radius: 10px;
      padding: 20px;
      max-width: 1000px;
      margin: auto;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    .form-left, .form-right {
      flex: 1;
      min-width: 300px;
      padding: 15px;
    }

    .main-image {
      width: 100%;
      height: 250px;
      border-radius: 10px;
      background-color: #eee;
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
      margin-bottom: 15px;
      cursor: pointer;
      border: 2px dashed #ccc;
      position: relative;
    }

    .main-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }

    .main-image .edit-icon {
      position: absolute;
      top: 10px;
      right: 10px;
      background-color: rgba(0, 0, 0, 0.6);
      color: #fff;
      padding: 6px 9px;
      border-radius: 50%;
      cursor: pointer;
    }

    .thumbs {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
    }

    .thumb-box {
      width: 80px;
      height: 80px;
      background-color: #eee;
      border-radius: 6px;
      overflow: hidden;
      border: 1px dashed #ccc;
      position: relative;
      cursor: pointer;
    }

    .thumb-box img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .thumb-box .edit-icon {
      position: absolute;
      top: 5px;
      right: 5px;
      background-color: rgba(0, 0, 0, 0.6);
      color: #fff;
      padding: 4px 6px;
      border-radius: 50%;
      font-size: 12px;
    }

    .form-right input, .form-right textarea {
      width: 100%;
      padding: 10px;
      margin-top: 10px;
      margin-bottom: 20px;
      border-radius: 5px;
      border: 1px solid #ccc;
      font-size: 16px;
    }

    .form-right label {
      font-weight: bold;
    }

    .submit-btn {
      margin-top: 20px;
      width: 100%;
      padding: 14px;
      background-color: #3498db;
      color: #fff;
      font-size: 18px;
      border: none;
      border-radius: 6px;
      cursor: pointer;
    }

    .submit-btn:hover {
      background-color: #2980b9;
    }

    @media(max-width: 768px) {
      .form-left, .form-right {
        min-width: 100%;
      }

      .back-button {
          left: auto;
          top: 72px;
          right: 20px;
  }

    }
  </style>
</head>
<body>



<!-- ✅ Header -->
<section id="header">
        <a href="#"><img src="../image/logo.png" class="logo" alt=""></a>

        <div>
            <ul id="navbar">
                <li><a href="../index.php">Home</a></li>
                <li><a href="#shop.php">Shop</a></li>
                <li><a href="#about.php">About</a></li>
                <li><a href="#">Contact</a></li>
                <li><a href="dashboard.php">Profile</a></li>
                <li><a class="active" href="#upload_product.php">✏️ Edit product</a></li>
                
                 
                 
                <a href="#" id="close"><i class="fa-solid fa-xmark"></i></a>  
            </ul>
        </div>

        <div id="mobile">
            
            <i id="bar" class="fas fa-outdent"></i>
        </div>
    </section>


<!-- ✅ Form -->
<section >
  <form class="container" method="POST" enctype="multipart/form-data">
    <div class="form-left">
      <label>Main Image</label>
      <div class="main-image" onclick="document.getElementById('mainImageInput').click();">
        <img id="mainImagePreview" src="../uploads/<?php echo htmlspecialchars($product['image']); ?>" />
        <div class="edit-icon">✏️</div>
      </div>
      <input type="file" id="mainImageInput" name="image" accept="image/*" style="display:none;" onchange="previewMainImage(event)" />

      <label>Other Images</label>
      <div class="thumbs">
        <?php
          for ($i = 0; $i < 10; $i++):
            $img = isset($otherImages[$i]) ? $otherImages[$i] : '';
        ?>
          <div class="thumb-box" onclick="document.getElementById('image<?php echo $i; ?>').click();">
            <?php if ($img): ?>
              <img id="thumbPreview<?php echo $i; ?>" src="../uploads/<?php echo htmlspecialchars($img); ?>" />
            <?php else: ?>
              <img id="thumbPreview<?php echo $i; ?>" src="https://via.placeholder.com/80" />
            <?php endif; ?>
            <div class="edit-icon">✏️</div>
          </div>
          <input type="file" name="image<?php echo $i; ?>" id="image<?php echo $i; ?>" accept="image/*" style="display:none;" onchange="previewThumb(event, <?php echo $i; ?>)" />
        <?php endfor; ?>
      </div>
    </div>

    <div class="form-right">
      <label for="title">Product Title</label>
      <input type="text" name="title" id="title" value="<?php echo htmlspecialchars($product['title']); ?>" required>

      <label for="description">Description</label>
      <textarea name="description" id="description" rows="10" required><?php echo htmlspecialchars($product['description']); ?></textarea>

      <label for="price">Price (BDT)</label>
      <input type="number" step="0.01" name="price" id="price" value="<?php echo htmlspecialchars($product['price']); ?>" required>

      <button class="submit-btn" type="submit">Update Product</button>
    </div>
  </form>
</section>

<script>
  let bar = document.getElementById('bar');
let nav = document.getElementById('navbar');
let mobile = document.getElementById('mobile');
let close = document.getElementById('close');

if (bar) {
    bar.addEventListener('click', () => {
        nav.classList.add('active');
        mobile.classList.add('hide'); // মোবাইল cart & bar আইকন হাইড করো
    });
}

if (close) {
    close.addEventListener('click', () => {
        nav.classList.remove('active');
        mobile.classList.remove('hide'); // আবার দেখাও
    });
}

  function previewMainImage(event) {
    const reader = new FileReader();
    reader.onload = function () {
      document.getElementById('mainImagePreview').src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  }

  function previewThumb(event, index) {
    const reader = new FileReader();
    reader.onload = function () {
      document.getElementById('thumbPreview' + index).src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
  }
</script>

<script src="https://kit.fontawesome.com/c9847c48a6.js" crossorigin="anonymous"></script>
</body>
</html>
