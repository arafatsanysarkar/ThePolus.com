<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'seller') {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if ($new_password !== $confirm_password) {
        die("নতুন পাসওয়ার্ড দুইবার মিলছে না।");
    }

    $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($hashed_password);
    $stmt->fetch();
    $stmt->close();

    if (!password_verify($current_password, $hashed_password)) {
        die("বর্তমান পাসওয়ার্ড সঠিক নয়।");
    }

    $new_hashed = password_hash($new_password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
    $stmt->bind_param("si", $new_hashed, $user_id);

    if ($stmt->execute()) {
        echo "✅ পাসওয়ার্ড সফলভাবে আপডেট হয়েছে। <a href='dashboard.php'>ফিরে যান</a>";
    } else {
        echo "❌ আপডেট করতে সমস্যা হয়েছে।";
    }

    $stmt->close();
}
?>
