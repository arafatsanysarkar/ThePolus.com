<?php
session_start();
include '../includes/db.php';

// Count total items in cart
$_SESSION['cart_count'] = 0;
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $_SESSION['cart_count'] += $item['quantity'];
    }
}

// Check if seller
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'seller') {
    header('Location: ../login.php');
    exit;
}

$seller_id = $_SESSION['user_id'];

// Get user info
$query = "SELECT name, email, brand_name, brand_image FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $seller_id);
$stmt->execute();
$stmt->bind_result($seller_name, $seller_email, $seller_brand_name, $seller_brand_image);
$stmt->fetch();
$stmt->close();

// Get seller products
$query = "SELECT * FROM products WHERE seller_id = ? ORDER BY id DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $seller_id);
$stmt->execute();
$result = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seller Dashboard</title>
    <link rel="stylesheet" href="../assets/navstyles.css">
    <link rel="stylesheet" href="../assets/styles1.css">
    <style>
        .user-info {
            text-align: center;
            margin: 30px auto;
        }

        .user-info img {
            width: 120px;
            height: 120px;
            object-fit: cover;
            border-radius: 50%;
            border: 3px solid #333;
            margin-bottom: 5px;
        }

        .user-info h2 {
            margin-top: 5px;
            margin-bottom: 10px;
            font-size: 24px;
        }

        .user-info p {
            margin: 5px 0;
        }

        .user-info form {
            margin-top: 10px;
            margin-bottom: 15px;
        }

        .user-info input[type="text"],
        .user-info input[type="file"],
        .user-info input[type="password"] {
            padding: 10px;
            margin: 5px 0;
            width: 100%;
            max-width: 300px;
        }

        .btn-edit {
            background-color: #007BFF;
            color: white;
            padding: 8px 16px;
            text-decoration: none;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            margin-bottom: 10px;
        }

        .btn-save {
            background-color: #28a745;
            color: white;
            padding: 8px 16px;
            border-radius: 5px;
            border: none;
            margin-top: 10px;
            cursor: pointer;
        }

        .btn-delete {
            background-color: #dc3545;
            color: white;
            display: inline-block;
            padding: 8px 16px;
            border-radius: 5px;
            text-decoration: none;
        }

        .btn-view-orders {
            background-color: #6f42c1;
            color: white;
            padding: 8px 16px;
            border-radius: 5px;
            text-decoration: none;
        }
    </style>
</head>
<body>

<section id="header">
    <a href="#"><img src="../image/logo.png" class="logo" alt=""></a>
    <div>
        <ul id="navbar">
            <li><a href="../index.php">Home</a></li>
            <li><a href="#blog.html">Blog</a></li>
            <li><a href="#about.html">About</a></li>
            <li><a href="#contact.html">Contact</a></li>
            <li><a class="active" href="dashboard.php">Profile</a></li>
            <li id="lg-bag">
                <a href="../cart.php">
                    <i class="cart">🛒</i>
                    <?php if (!empty($_SESSION['cart_count'])): ?>
                        <span class="cart-badge"><?php echo $_SESSION['cart_count']; ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <a href="#" id="close"><i class="fa-solid fa-xmark"></i></a>
        </ul>
    </div>
    <div id="mobile">
        <a href="../cart.php" class="mobile-cart">
            <i class="cart">🛒</i>
            <?php if (!empty($_SESSION['cart_count'])): ?>
                <span class="cart-badge"><?php echo $_SESSION['cart_count']; ?></span>
            <?php endif; ?>
        </a>
        <i id="bar" class="fas fa-outdent"></i>
    </div>
</section>

<h1>Welcome to Seller Dashboard</h1>

<!-- User Info -->
<div class="user-info">
    <?php if (!empty($seller_brand_image)) { ?>
        <img src="../uploads/<?php echo htmlspecialchars($seller_brand_image); ?>" alt="Brand Image">
    <?php } else { ?>
        <img src="https://via.placeholder.com/120" alt="Default Brand Image">
    <?php } ?>

    <h2><?php echo htmlspecialchars($seller_brand_name ?: 'No Brand Name'); ?></h2>
    <p>Name: <?php echo htmlspecialchars($seller_name); ?></p>
    <p>Email: <?php echo htmlspecialchars($seller_email); ?></p>

    <button onclick="toggleBrandForm()" class="btn-edit">ব্র্যান্ড আপডেট করুন</button>
    <form id="brandForm" action="update_brand.php" method="POST" enctype="multipart/form-data" style="display: none;">
        <input type="text" name="brand_name" placeholder="নতুন ব্র্যান্ড নাম" value="<?php echo htmlspecialchars($seller_brand_name); ?>">
        <input type="file" name="brand_image">
        <button type="submit" class="btn-save">সংরক্ষণ করুন</button>
    </form>

    <!-- Password Update Section -->
    <button onclick="togglePasswordForm()" class="btn-edit">পাসওয়ার্ড পরিবর্তন করুন</button>
    <form id="passwordForm" action="update_password.php" method="POST" style="display: none;">
        <input type="password" name="current_password" placeholder="বর্তমান পাসওয়ার্ড" required>
        <input type="password" name="new_password" placeholder="নতুন পাসওয়ার্ড" required>
        <input type="password" name="confirm_password" placeholder="নতুন পাসওয়ার্ড পুনরায়" required>
        <button type="submit" class="btn-save">আপডেট করুন</button>
    </form>

    <a href="../logout.php" class="btn btn-delete">Logout</a>
</div>

<div class="user-info">
    <h3>Saved Products</h3>
    <p><a href="../saved_products.php" class="btn btn-view-orders">View</a></p>
</div>


<!-- View Orders -->
<div class="user-info">
    <h3>Orders</h3>
    <p><a href="../my_orders.php" class="btn btn-view-orders">Orders I Placed</a></p>
    <p><a href="seller_order_list.php" class="btn btn-view-orders">Orders from Customers</a></p>
</div>



<!-- Seller Products -->
<h2>Your Products</h2>
<div style="text-align: center; margin: 10px 0;">
    <a href="upload_product.php" class="btn btn-add">+ Add New Product</a>
</div>

<table>
    <thead>
        <tr>
            <th>Image</th>
            <th>Product Title</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($product = $result->fetch_assoc()) { ?>
            <tr>
                <td>
                    <?php if (!empty($product['image'])) { ?>
                        <img src="../uploads/<?php echo htmlspecialchars($product['image']); ?>" alt="Product Image" style="width: 60px; height: auto;">
                    <?php } else { ?>
                        <span>No Image</span>
                    <?php } ?>
                </td>
                <td><?php echo htmlspecialchars($product['title']); ?></td>
                <td>
                    <a href="edit_product.php?id=<?php echo $product['id']; ?>" class="btn btn-edit">Edit</a>
                    <a href="delete_product.php?id=<?php echo $product['id']; ?>" class="btn btn-delete" onclick="return confirm('Are you sure you want to delete this product?');">Delete</a>
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>

<script>
function toggleBrandForm() {
    var form = document.getElementById('brandForm');
    form.style.display = form.style.display === 'none' ? 'block' : 'none';
}

function togglePasswordForm() {
    var form = document.getElementById('passwordForm');
    form.style.display = form.style.display === 'none' ? 'block' : 'none';
}

let bar = document.getElementById('bar');
let nav = document.getElementById('navbar');
let mobile = document.getElementById('mobile');
let close = document.getElementById('close');

if (bar) {
    bar.addEventListener('click', () => {
        nav.classList.add('active');
        mobile.classList.add('hide');
    });
}

if (close) {
    close.addEventListener('click', () => {
        nav.classList.remove('active');
        mobile.classList.remove('hide');
    });
}
</script>
<script src="https://kit.fontawesome.com/c9847c48a6.js" crossorigin="anonymous"></script>
</body>
</html>
