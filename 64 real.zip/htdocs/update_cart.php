<?php
session_start();

if (isset($_POST['id'], $_POST['size'], $_POST['quantity'])) {
    $id = $_POST['id'];
    $size = $_POST['size'];
    $quantity = $_POST['quantity'];

    foreach ($_SESSION['cart'] as &$item) {
        if ($item['id'] == $id) {
            $item['size'] = $size;
            $item['quantity'] = $quantity;
            break;
        }
    }

    echo 'updated';
}
