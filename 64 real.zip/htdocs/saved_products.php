<?php
session_start();
include 'includes/db.php';
include('includes/functions.php');

$user_id = $_SESSION['user_id'] ?? null;

if (!$user_id) {
    header("Location: login.php");
    exit;
}

// ফেভারিট প্রোডাক্টস লোড করো
$query = "SELECT p.* FROM saved_products sp 
          JOIN products p ON sp.product_id = p.id 
          WHERE sp.user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// রিমুভ বাটনের জন্য কোড
if (isset($_GET['remove_id'])) {
    $remove_id = $_GET['remove_id'];
    $remove_query = "DELETE FROM saved_products WHERE user_id = ? AND product_id = ?";
    $remove_stmt = $conn->prepare($remove_query);
    $remove_stmt->bind_param("ii", $user_id, $remove_id);
    $remove_stmt->execute();
    header("Location: my_saved_products.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Saved Products</title>
    <link rel="stylesheet" href="../assets/navstyles.css">
    
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            background: #f4f4f4;
        }

        h2 {
            text-align: center;
            padding: 20px;
        }

        .product-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            padding: 20px;
        }

        .product-card {
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            background-color: #fff;
        }

        .product-card h3 {
            font-size: 18px;
            color: #333;
            margin-bottom: 10px;
        }

        .product-card .price {
            font-size: 16px;
            color: #e74c3c;
            margin-bottom: 10px;
        }

        .product-card .action-btns {
            display: flex;
            justify-content: space-between;
        }

        .product-card .action-btns button {
            padding: 10px 15px;
            font-size: 14px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            text-decoration: none; /* আন্ডারলাইন সরানো হয়েছে */
        }

        .product-card .action-btns .remove-btn {
            background-color: #e74c3c;
            color: white;
        }

        .product-card .action-btns .remove-btn:hover {
            background-color: #c0392b;
        }

        .product-card .action-btns .view-btn {
            background-color: #3498db;
            color: white;
        }

        .product-card .action-btns .view-btn:hover {
            background-color: #2980b9;
        }

        .back-button {
  position: fixed;
  top: 110px;
  left: 25px;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 15px;
  text-decoration: none;
  background-color: black;
  color: white;
  border-radius: 30px;
  font-size: 16px;
  z-index: 999;
  transition: background-color 0.3s ease;
}


    .back-button img {
      width: 20px;
      height: 20px;
    }

    .back-button:hover {
      background-color: #2980b9;
    }

        @media (max-width: 576px) {
            

            .back-button {
          left: 20px;
          top: 510px;
          right: auto;
  }
        }

    </style>
</head>
<body>

</head>
<body>

    <section id="header">
        <a href="#"><img src="image/logo.png" class="logo" alt=""></a>

        <div>
            <ul id="navbar">
                <li><a href="../index.php">Home</a></li>
                <li><a href="#blog.html">Blog</a></li>
                <li><a href="#about.html">About</a></li>
                <li><a href="#contact.html">Contact</a></li>
                 <li><a class="active" href="dashboard.php">Profile</a></li>
                 
                 <li id="lg-bag">
    <a href="cart.php">
        <i class="cart">🛒</i>
        <?php if (!empty($_SESSION['cart_count'])): ?>
            <span class="cart-badge"><?php echo $_SESSION['cart_count']; ?></span>
        <?php endif; ?>
    </a>
</li>
 
                <a href="#" id="close"><i class="fa-solid fa-xmark"></i></a>  
            </ul>
        </div>

        <div id="mobile">
    <a href="cart.php" class="mobile-cart">
        <i class="cart">🛒</i>
        <?php if (!empty($_SESSION['cart_count'])): ?>
            <span class="cart-badge"><?php echo $_SESSION['cart_count']; ?></span>
        <?php endif; ?>
    </a>
    <i id="bar" class="fas fa-outdent"></i>
</div>

</section>






<!-- 🔙 Back Button -->
<a href="<?php 
    if (isSeller()) {
        echo 'seller/dashboard.php';
    } elseif (isCustomer()) {
        echo 'customer/dashboard.php';
    }
?>" class="back-button">
  <img src="https://img.icons8.com/ios-filled/50/ffffff/left.png" alt="Back" />
  <span></span>
</a>




<h2>My Saved Products</h2>

<div class="product-container">
    <?php while ($row = $result->fetch_assoc()): ?>
        <div class="product-card">
            <!-- এখানে ছবিটি সরানো হয়েছে -->
            <h3><?= htmlspecialchars($row['title']) ?></h3>
            <p class="price">৳<?= htmlspecialchars($row['price']) ?></p>
            <div class="action-btns">
                <a href="product.php?id=<?= $row['id'] ?>" style="display:inline;" class="view-btn">View Details</a>
                <form action="remove_product.php" method="post" style="display:inline;">
    <input type="hidden" name="product_id" value="<?= $row['id'] ?>">
    <button type="submit" class="remove-btn">Remove</button>
</form>

            </div>
        </div>
    <?php endwhile; ?>
</div>

</body>
</html>
