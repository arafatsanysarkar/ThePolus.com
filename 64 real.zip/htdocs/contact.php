<?php
session_start();
include 'includes/db.php';
include('includes/functions.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Contact Us</title>
  <style>
    * {
      box-sizing: border-box;
    }
    body {
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      padding: 0;
      background: #f4f7f9;
      color: #333;
    }
    .container {
      max-width: 1100px;
      margin: 0 auto;
      padding: 40px 20px;
    }
    h1 {
      text-align: center;
      margin-bottom: 40px;
      color: #2c3e50;
    }

    .contact-wrapper {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 40px;
    }

    .contact-info {
      background: #fff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }

    .contact-info h3 {
      margin-bottom: 20px;
      color: #2980b9;
    }

    .info-item {
      margin-bottom: 15px;
    }

    .info-item strong {
      display: block;
      margin-bottom: 5px;
    }

    .contact-form {
      background: #fff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }

    .contact-form form {
      display: flex;
      flex-direction: column;
    }

    .contact-form label {
      margin-bottom: 5px;
      font-weight: bold;
    }

    .contact-form input,
    .contact-form textarea {
      margin-bottom: 20px;
      padding: 12px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 15px;
    }

    .contact-form textarea {
      resize: vertical;
      min-height: 120px;
    }

    .contact-form button {
      padding: 12px;
      background: #2980b9;
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 16px;
      cursor: pointer;
      transition: background 0.3s ease;
    }

    .contact-form button:hover {
      background: #21618c;
    }

    .map {
      margin-top: 40px;
      border-radius: 12px;
      overflow: hidden;
    }

    @media (max-width: 768px) {
      .contact-wrapper {
        grid-template-columns: 1fr;
      }
    }
  </style>

  <link rel="stylesheet" href="assets/navstyles.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="https://kit.fontawesome.com/c9847c48a6.js" crossorigin="anonymous"></script>
</head>
<body>



<section id="header">
  <a href="#"><img src="image/logo.png" class="logo" alt=""></a>
  <div>
    <ul id="navbar">
      <li><a href="../index.php">Home</a></li>
      <li><a href="#contact.html">shop</a></li>
      <li><a href="#about.html">About</a></li>
      <li><a class="active" href="#contact.html">Contact</a></li>
      
      <?php if (isLoggedIn()): ?>
                <?php if (isSeller()): ?>
                    <li><a href="seller/dashboard.php">Profile</a></li>
                <?php elseif (isCustomer()): ?>
                    <li><a href="customer/dashboard.php">Profile</a></li>
                <?php endif; ?>
            <?php else: ?>
                <li><a href="login.php">Log in</a></li>
            <?php endif; ?>
      
      

      <li id="lg-bag">
        <a href="cart.php">
          <i class="cart">🛒</i>
          <?php if ($cart_count > 0): ?>
            <span class="cart-badge"><?php echo $cart_count; ?></span>
          <?php endif; ?>
        </a>
      </li>
      <a href="#" id="close"><i class="fa-solid fa-xmark"></i></a>
    </ul>
  </div>
  <div id="mobile">
    <a href="cart.php" class="mobile-cart">
      <i class="cart">🛒</i>
      <?php if ($cart_count > 0): ?>
        <span class="cart-badge"><?php echo $cart_count; ?></span>
      <?php endif; ?>
    </a>
    <i id="bar" class="fas fa-outdent"></i>
  </div>
</section>



  <div class="container">
    <h1>Contact Us</h1>
    <div class="contact-wrapper">
      <!-- Contact Info -->
      <div class="contact-info">
        <h3>📍 Our Office</h3>
        <div class="info-item">
          <strong>Address:</strong>
          Kosba, Dinajpur, Bangladesh
        </div>
        <div class="info-item">
          <strong>Phone:</strong>
          +880 1766595965
        </div>
        <div class="info-item">
          <strong>Email:</strong>
          thepolus333@gmail.com
        </div>
        <div class="info-item">
          <strong>Hours:</strong>
          Saturday - Thursday: 9AM - 9PM
        </div>
      </div>

      <!-- Contact Form -->
      <div class="contact-form">
        <h3>📬 Send a Message</h3>
        <form action="submit_contact.php" method="post">
          <label for="name">Full Name</label>
          <input type="text" id="name" name="name" required />

          <label for="email">Email Address</label>
          <input type="email" id="email" name="email" required />

          <label for="message">Message</label>
          <textarea id="message" name="message" required></textarea>

          <button type="submit">Send Message</button>
        </form>
      </div>
    </div>

    <!-- Google Maps Embed -->
    <div class="map">
      
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3651.846831539539!2d88.6300001!3d25.6061668!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755b8932c6e56d9%3A0x7acb340b4741ef35!2s25%C2%B036'22.2%22N%2088%C2%B037'48.0%22E!5e0!3m2!1sen!2sbd!4v1617636747834!5m2!1sen!2sbd"
        width="100%"
        height="350"
        style="border:0;"
        allowfullscreen=""
        loading="lazy"
      ></iframe>
    </div>
  </div>


  <script>
let bar = document.getElementById('bar');
let nav = document.getElementById('navbar');
let mobile = document.getElementById('mobile');
let close = document.getElementById('close');

if (bar) {
    bar.addEventListener('click', () => {
        nav.classList.add('active');
        mobile.classList.add('hide'); // মোবাইল cart & bar আইকন হাইড করো
    });
}

if (close) {
    close.addEventListener('click', () => {
        nav.classList.remove('active');
        mobile.classList.remove('hide'); // আবার দেখাও
    });
}
</script>
</body>
</html>
