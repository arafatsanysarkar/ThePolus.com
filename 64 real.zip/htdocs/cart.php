<?php
session_start();
include 'includes/db.php';

$cart_count = 0;
if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $cart_count += isset($item['quantity']) ? (int)$item['quantity'] : 1;
    }
}

$cart_empty = false;
$products = [];

if (!isset($_SESSION['cart']) || count($_SESSION['cart']) == 0) {
    $cart_empty = true;
} else {
    $cart_ids = array_map(fn($item) => $item['id'], $_SESSION['cart']);
    if (empty($cart_ids)) {
        $cart_empty = true;
    } else {
        $cart_items_str = implode(",", array_map('intval', $cart_ids));
        $query = "SELECT * FROM products WHERE id IN ($cart_items_str)";
        $result = $conn->query($query);
        while ($row = $result->fetch_assoc()) {
            $products[$row['id']] = $row;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Stylish Cart</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/navstyles.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="https://kit.fontawesome.com/c9847c48a6.js" crossorigin="anonymous"></script>
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        

        h1 {
            text-align: center;
            font-size: 2.5rem;
            margin: 30px 0;
        }

        .cart-container {
            max-width: 900px;
            margin: auto;
        }

        .cart-item {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 6px 12px rgba(0,0,0,0.05);
            margin-bottom: 25px;
            padding: 20px;
            display: flex;
            align-items: flex-start;
            gap: 20px;
            transition: transform 0.2s;
        }

        .cart-item:hover {
            transform: scale(1.01);
        }

        .cart-item img {
            width: 140px;
            height: 140px;
            object-fit: cover;
            border-radius: 12px;
        }

        .cart-details {
            flex: 1;
        }

        .cart-details h2 {
            font-size: 1.4rem;
            margin-bottom: 10px;
        }

        .cart-details p,
        .cart-details label {
            font-size: 1.05rem;
            margin-bottom: 8px;
            display: block;
        }

        .cart-details select,
        .cart-details input[type="number"] {
            padding: 10px;
            font-size: 1rem;
            margin-top: 6px;
            margin-bottom: 12px;
            width: 100%;
            max-width: 220px;
            border-radius: 8px;
            border: 1px solid #ccc;
        }

        .cart-details button {
            padding: 10px 24px;
            background: #007b5e;
            color: #fff;
            font-size: 1rem;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .cart-details button:hover {
            background: #005f48;
        }

        .remove-btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: #ffe6e6;
            color: #b40000;
            border: 1px solid #b40000;
            padding: 8px 16px;
            border-radius: 6px;
            font-size: 0.95rem;
            font-weight: 600;
            text-decoration: none;
            margin-top: 10px;
            transition: background 0.3s ease, color 0.3s ease;
        }

        .remove-btn:hover {
            background: #ffcccc;
            color: #900000;
        }

        .checkout {
            text-align: center;
            margin-top: 40px;
        }

        .checkout p {
            font-size: 1.6rem;
            margin-bottom: 20px;
        }

        .checkout a {
            padding: 15px 35px;
            background-color: #333;
            color: #fff;
            font-size: 1.2rem;
            border-radius: 10px;
            text-decoration: none;
            transition: background 0.3s ease;
        }

        .checkout a:hover {
            background-color: #111;
        }

        .empty-message {
            text-align: center;
            font-size: 2rem;
            color: #999;
            padding: 100px 20px;
        }

        @media (max-width: 768px) {
            .cart-item {
                flex-direction: column;
                align-items: center;
                text-align: center;
            }

            .cart-details {
                width: 100%;
            }

            .cart-details select,
            .cart-details input {
                max-width: 100%;
            }

            .cart-details h2 {
                font-size: 1.6rem;
            }

            nav {
                flex-direction: column;
                gap: 10px;
            }

            nav a {
                font-size: 1.3rem;
            }

            h1 {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>

<section id="header">
  <a href="#"><img src="image/logo.png" class="logo" alt=""></a>
  <div>
    <ul id="navbar">
      <li><a href="../index.php">Home</a></li>
      <li><a href="#">Shop</a></li>
      <li><a href="#about.html">About</a></li>
      <li><a href="#contact.html">Contact</a></li>
      <li><a href="dashboard.php">Profile</a></li>

      <li id="lg-bag">
        <a href="cart.php" class="active">
          <i class="cart">🛒</i>
          <?php if ($cart_count > 0): ?>
            <span class="cart-badge"><?php echo $cart_count; ?></span>
          <?php endif; ?>
        </a>
      </li>
      <a href="#" id="close"><i class="fa-solid fa-xmark"></i></a>
    </ul>
  </div>
  <div id="mobile">
    <a href="cart.php" class="mobile-cart" class="active">
      <i class="cart">🛒</i>
      <?php if ($cart_count > 0): ?>
        <span class="cart-badge"><?php echo $cart_count; ?></span>
      <?php endif; ?>
    </a>
    <i id="bar" class="fas fa-outdent"></i>
  </div>
</section>

<h1>🛒 Your Shopping Cart</h1>

<div class="cart-container">
<?php if ($cart_empty): ?>
    <div class="empty-message">🧺 Your cart is empty.</div>
<?php else: ?>
    <?php 
    $total_price = 0;
    foreach ($_SESSION['cart'] as $item): 
        $product = $products[$item['id']];
        $total_item_price = $product['price'] * $item['quantity'];
        $total_price += $total_item_price;
    ?>
    <div class="cart-item" id="item-<?php echo $item['id'].'-'.$item['size']; ?>">
        <img src="uploads/<?php echo htmlspecialchars($product['image']); ?>" alt="Product Image">
        <div class="cart-details">
            <h2><?php echo htmlspecialchars($product['title']); ?></h2>
            <p>Price: $<?php echo $product['price']; ?></p>

            <label>Size:
  <select class="size-select" data-id="<?php echo $product['id']; ?>">

    <?php 
    // Initialize the sizes array
    $sizes = [];
    
    // If it's a pant, provide pant sizes; otherwise, provide other sizes
    if (stripos($product['title'], 'pant') !== false) {
        $sizes = [30, 31, 32, 33, 34, 35, 36, 37]; // Pant সাইজ
    } else {
        $sizes = ['S', 'M', 'L', 'XL', 'XXL', 'no-need']; // T-Shirt or other sizes
    }

    // Check if 'no-need' should be shown or not
    $show_no_need = in_array('no-need', $sizes) && $item['size'] == 'no-need';
    
    if ($show_no_need): ?>
        <!-- Show 'no-need' if it's selected -->
        <option value="no-need" selected>সিলেক্ট করতে হবে না।</option>
    <?php else: 
        // Show regular sizes if 'no-need' is not selected
        foreach ($sizes as $sz):
            if ($sz !== 'no-need'): // Skip 'no-need' option in the loop
    ?>
                <option value="<?php echo $sz; ?>" <?php if ($item['size'] == $sz) echo 'selected'; ?>>
                    <?php echo $sz; ?>
                </option>
    <?php 
            endif;
        endforeach;
    endif;
    ?>

    
</select>

</label>


            <label>Quantity:
                <input type="number" class="quantity-input" data-id="<?php echo $product['id']; ?>" value="<?php echo $item['quantity']; ?>" min="1">
            </label>

            <button onclick="updateCart(<?php echo $product['id']; ?>)">Update</button>
            <br>
            <a class="remove-btn" href="remove_from_cart.php?id=<?php echo $product['id']; ?>&size=<?php echo $item['size']; ?>">
                <i class="fas fa-trash"></i> Remove
            </a>
            <p><strong>Total:</strong> $<?php echo number_format($total_item_price, 2); ?></p>
        </div>
    </div>
    <?php endforeach; ?>

    <div class="checkout">
        <p>Total Price: $<?php echo number_format($total_price, 2); ?></p>
        <a href="checkout.php">Proceed to Checkout</a>
    </div>
<?php endif; ?>
</div>

<script>
let bar = document.getElementById('bar');
let nav = document.getElementById('navbar');
let mobile = document.getElementById('mobile');
let close = document.getElementById('close');

if (bar) {
    bar.addEventListener('click', () => {
        nav.classList.add('active');
        mobile.classList.add('hide'); // মোবাইল cart & bar আইকন হাইড করো
    });
}

if (close) {
    close.addEventListener('click', () => {
        nav.classList.remove('active');
        mobile.classList.remove('hide'); // আবার দেখাও
    });
}



function updateCart(id) {
    const size = document.querySelector(`.size-select[data-id="${id}"]`).value;
    const quantity = document.querySelector(`.quantity-input[data-id="${id}"]`).value;

    const xhr = new XMLHttpRequest();
    xhr.open("POST", "update_cart.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    xhr.onload = function () {
        if (xhr.status === 200) {
            location.reload();
        }
    };

    xhr.send(`id=${id}&size=${size}&quantity=${quantity}`);
}
</script>

</body>
</html>

