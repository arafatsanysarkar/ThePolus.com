<?php
session_start();
include 'includes/db.php'; // Adjust path if needed

// Fetch all orders with buyer info
$orders_query = "SELECT * FROM orders ORDER BY id DESC";
$orders_result = $conn->query($orders_query);

// Collect all order items by order ID
$order_items = [];
$order_items_query = "SELECT * FROM order_items";
$items_result = $conn->query($order_items_query);
while ($item = $items_result->fetch_assoc()) {
    $order_items[$item['order_id']][] = $item;
}

// Fetch product titles and images
$product_titles = [];
$products_query = "SELECT id, title, image FROM products";
$products_result = $conn->query($products_query);
while ($product = $products_result->fetch_assoc()) {
    $product_titles[$product['id']] = [
        'title' => $product['title'],
        'image' => $product['image']
    ];
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Admin - All Orders</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f8;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #34495e;
        }
        .order {
            background: white;
            margin-bottom: 25px;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
        }
        .order h3 {
            margin-top: 0;
            color: #2c3e50;
        }
        .order p {
            margin: 5px 0;
            font-size: 15px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 12px;
        }
        table th, table td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
            font-size: 14px;
        }
        table th {
            background: #2ecc71;
            color: white;
        }
        .no-orders {
            text-align: center;
            font-size: 18px;
            color: #777;
            padding: 50px;
        }
        .product-img {
            width: 50px;
            height: auto;
            margin-right: 8px;
            vertical-align: middle;
            border-radius: 6px;
        }
    </style>
</head>
<body>

<h1>📦 All Orders - Admin Panel</h1>

<?php if ($orders_result->num_rows > 0): ?>
    <?php while ($order = $orders_result->fetch_assoc()): ?>
        <div class="order">
            <h3>🧾 Order #<?php echo $order['id']; ?></h3>
            <p><strong>Buyer:</strong> <?php echo htmlspecialchars($order['name']); ?> | 📞 <?php echo htmlspecialchars($order['phone']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($order['email']); ?></p>
            <p><strong>Address:</strong> <?php echo htmlspecialchars($order['address']); ?></p>
            <p><strong>Location:</strong> <?php echo htmlspecialchars($order['location']); ?></p>
            <p><strong>Total Price:</strong> $<?php echo number_format($order['total_price'], 2); ?></p>

            <table>
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Size</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $items = $order_items[$order['id']] ?? [];
                        foreach ($items as $item):
                            $product_info = $product_titles[$item['product_id']] ?? ['title' => 'Unknown Product', 'image' => ''];
                            $product_name = $product_info['title'];
                            $product_image = $product_info['image'];
                            $subtotal = $item['price'] * $item['quantity'];
                    ?>
                    <tr>
                        <td>
                            <img src="uploads/<?php echo htmlspecialchars($product_image); ?>" alt="<?php echo htmlspecialchars($product_name); ?>" class="product-img">
                            <?php echo htmlspecialchars($product_name); ?>
                        </td>
                        <td><?php echo htmlspecialchars($item['size']); ?></td>
                        <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                        <td>$<?php echo number_format($item['price'], 2); ?></td>
                        <td>$<?php echo number_format($subtotal, 2); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endwhile; ?>
<?php else: ?>
    <div class="no-orders">❌ No orders found.</div>
<?php endif; ?>

</body>
</html>
