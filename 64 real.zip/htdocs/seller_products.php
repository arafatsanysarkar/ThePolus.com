<?php
include 'includes/db.php';

if (!isset($_GET['seller_id'])) {
    echo "Seller ID missing!";
    exit;
}

$seller_id = intval($_GET['seller_id']);

$seller_info_query = "SELECT brand_name, email, brand_image FROM users WHERE id = ?";
$stmt = $conn->prepare($seller_info_query);
$stmt->bind_param("i", $seller_id);
$stmt->execute();
$seller_info = $stmt->get_result()->fetch_assoc();

if (!$seller_info) {
    echo "Seller not found!";
    exit;
}

$products_query = "SELECT * FROM products WHERE seller_id = ?";
$stmt = $conn->prepare($products_query);
$stmt->bind_param("i", $seller_id);
$stmt->execute();
$products_result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($seller_info['brand_name']); ?> - Products</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 20px;
            background: #f5f6fa;
            color: #333;
        }

        a {
            text-decoration: none;
        }

        .seller-header {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }

        .seller-header img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 50%;
            border: 2px solid #833a0a;
            background: #fff;
        }

        .seller-header h1 {
            font-size: 2rem;
            color: #2a9d8f;
            margin: 0;
        }

        .pro-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 25px;
        }

        .pro {
            background: #fff;
            border-radius: 12px;
            padding: 15px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.08);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            transition: 0.3s ease;
        }

        .pro:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.12);
        }

        .pro img {
            width: 100%;
            height: 180px;
            object-fit: contain;
            border-radius: 8px;
            margin-bottom: 12px;
            background: #fff;
        }

        .des {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            margin-top: auto;
        }

        .brand-name {
            font-size: 13px;
            font-weight: 600;
            color: #e67e22;
            margin-bottom: 6px;
        }

        .des h5 {
            font-size: 1rem;
            font-weight: 600;
            margin: 5px 0;
            color: #2c3e50;
        }

        .des h4 {
            font-size: 1.1rem;
            font-weight: bold;
            color: #27ae60;
            margin: 5px 0;
        }

        .cart {
            font-size: 20px;
            color: #2980b9;
            margin-top: 10px;
            transition: color 0.3s ease;
        }

        .cart:hover {
            color: #1abc9c;
        }

        @media (max-width: 600px) {
            body {
                padding: 10px;
            }

            .seller-header {
        justify-content: center; /* মোবাইলে মাঝখানে রাখবে */
    }

    .seller-header h1 {
        font-size: 1.3rem;
        white-space: nowrap; /* নাম ভেঙে নিচে না যায় */
        text-align: center;
    }

            .pro img {
                height: 150px;
            }
        }
    </style>
</head>
<body>

<div class="seller-header">
    <?php if (!empty($seller_info['brand_image'])): ?>
        <img src="uploads/<?php echo htmlspecialchars($seller_info['brand_image']); ?>" alt="<?php echo htmlspecialchars($seller_info['brand_name']); ?>">
    <?php else: ?>
        <img src="assets/default-seller.png" alt="No Image">
    <?php endif; ?>
    <h1><?php echo htmlspecialchars($seller_info['brand_name']); ?></h1>
</div>

<?php if ($products_result->num_rows > 0): ?>
    <div class="pro-container">
        <?php while ($row = $products_result->fetch_assoc()): ?>
            <div class="pro">
                <a href="product.php?id=<?php echo $row['id']; ?>">
                    <img src="uploads/<?php echo $row['image']; ?>" alt="<?php echo htmlspecialchars($row['title']); ?>">
                </a>
                <div class="des">
                    <div class="brand-name"><?php echo htmlspecialchars($seller_info['brand_name']); ?></div>
                    <h5><a href="product.php?id=<?php echo $row['id']; ?>"><?php echo htmlspecialchars($row['title']); ?></a></h5>
                    <h4>৳ <?php echo number_format($row['price'], 2); ?></h4>
                    <a href="product.php?id=<?php echo $row['id']; ?>"><i class="cart">🛒</i></a>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
<?php else: ?>
    <p>এই সেলার-এর কোন প্রডাক্ট পাওয়া যায়নি।</p>
<?php endif; ?>

</body>
</html>
