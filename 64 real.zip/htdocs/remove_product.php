<?php
session_start();
include 'includes/db.php';

$user_id = $_SESSION['user_id'] ?? null;

if (!$user_id) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])) {
    $product_id = intval($_POST['product_id']);

    // নিশ্চিতভাবে প্রোডাক্টটা ইউজারের সেভ লিস্টে আছে কিনা
    $check_query = "SELECT * FROM saved_products WHERE user_id = ? AND product_id = ?";
    $check_stmt = $conn->prepare($check_query);
    $check_stmt->bind_param("ii", $user_id, $product_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();

    if ($check_result->num_rows > 0) {
        // রিমুভ করো
        $delete_query = "DELETE FROM saved_products WHERE user_id = ? AND product_id = ?";
        $delete_stmt = $conn->prepare($delete_query);
        $delete_stmt->bind_param("ii", $user_id, $product_id);
        $delete_stmt->execute();
    }

    header("Location: saved_products.php");
    exit;
} else {
    // POST না হলে বা ID না থাকলে রিডিরেক্ট
    header("Location: saved_products.php");
    exit;
}
?>
