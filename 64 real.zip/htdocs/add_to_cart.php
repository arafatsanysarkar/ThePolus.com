<?php
session_start();
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$id = $_GET['id'];
$size = $_GET['size'];
$quantity = $_GET['quantity'];

// Ensure quantity is an integer
$quantity = intval($quantity);

// প্রতিটি আইটেমকে আলাদা হিসেবে রাখতে হলে ID, size এবং quantity একসাথে সেভ করবো
$item = ['id' => $id, 'size' => $size, 'quantity' => $quantity];

$already_added = false;
foreach ($_SESSION['cart'] as &$cart_item) {
    if ($cart_item['id'] == $id && $cart_item['size'] == $size) {
        $cart_item['quantity'] += $quantity;
        $already_added = true;
        break;
    }
}

if (!$already_added) {
    $_SESSION['cart'][] = $item;
}

// ✅ প্রোডাক্ট অ্যাড হবার পর cart.php তে রিডাইরেক্ট
header("Location: cart.php");
exit();
?>
