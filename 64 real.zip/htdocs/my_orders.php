<?php
session_start();
include 'includes/db.php';

include 'includes/functions.php'; // এই লাইনে তোমার auth/check ফাংশন গুলো থাকতে হবে



if (!isset($_SESSION['user_id'])) {
    echo "<h2 style='text-align:center; padding: 50px;'>Please <a href='login.php'>login</a> to view your orders.</h2>";
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch all orders for the user
$order_query = $conn->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC");
$order_query->bind_param("i", $user_id);
$order_query->execute();
$order_result = $order_query->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Orders</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: sans-serif;
            background: #f0f2f5;
            margin: 0;
            padding: 20px;
        }
        h2 {
            text-align: center;
            color: #2c3e50;
        }
        .order-box {
            background: #fff;
            margin: 20px auto;
            padding: 20px;
            border-radius: 12px;
            max-width: 800px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .product-item {
            border-top: 1px solid #ddd;
            padding-top: 10px;
            margin-top: 10px;
            display: flex;
            gap: 15px;
        }
        .product-item img {
            max-width: 100px;
            border-radius: 8px;
        }
        .product-details {
            flex: 1;
        }
        .no-order {
            text-align: center;
            padding: 50px;
            color: #999;
        }


        .back-button {
  position: fixed;
  top: 30px;
  left: 75px;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 15px;
  text-decoration: none;
  background-color: black;
  color: white;
  border-radius: 30px;
  font-size: 16px;
  z-index: 999;
  transition: background-color 0.3s ease;
}


    .back-button img {
      width: 20px;
      height: 20px;
    }

    .back-button:hover {
      background-color: #2980b9;
    }

        @media (max-width: 576px) {

            .back-button {
          left: 20px;
          top: 510px;
          right: auto;
  }
        }
    </style>
</head>
<body>


<!-- 🔙 Back Button -->
<?php
$backUrl = "../login.php"; // Default fallback URL

if (isLoggedIn()) {
    if (isSeller()) {
        $backUrl = "../seller/dashboard.php";
    } elseif (isCustomer()) {
        $backUrl = "../customer/dashboard.php";
    }
}
?>
<a href="<?php echo $backUrl; ?>" class="back-button">
  <img src="https://img.icons8.com/ios-filled/50/ffffff/left.png" alt="Back" />
  
</a>



<h2>📦 My Orders</h2>

<?php
if ($order_result->num_rows === 0) {
    echo "<div class='no-order'>You have no orders yet.</div>";
} else {
    while ($order = $order_result->fetch_assoc()) {
        echo "<div class='order-box'>";
        echo "<strong>Order ID:</strong> {$order['id']}<br>";
        echo "<strong>Total Price:</strong> ৳" . number_format($order['total_price'], 2) . "<br>";
        echo "<strong>Address:</strong> {$order['address']}<br>";
        echo "<strong>Date:</strong> " . date("F j, Y", strtotime($order['order_date'])) . "<br><br>";

        // Fetch items for this order
        $item_query = $conn->prepare("SELECT oi.*, p.title, p.image FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?");
        $item_query->bind_param("i", $order['id']);
        $item_query->execute();
        $item_result = $item_query->get_result();

        while ($item = $item_result->fetch_assoc()) {
            echo "<div class='product-item'>";
            echo "<img src='uploads/" . htmlspecialchars($item['image']) . "' alt=''>";
            echo "<div class='product-details'>";
            echo "<strong>" . htmlspecialchars($item['title']) . "</strong><br>";
            echo "Size: " . htmlspecialchars($item['size']) . "<br>";
            echo "Quantity: " . $item['quantity'] . "<br>";
            echo "Price: ৳" . number_format($item['price'], 2);
            echo "</div></div>";
        }

        $item_query->close();
        echo "</div>";
    }
}

$order_query->close();
?>

</body>
</html>
