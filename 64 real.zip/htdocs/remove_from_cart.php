<?php
session_start();

$id = $_GET['id'];
$size = $_GET['size'];

foreach ($_SESSION['cart'] as $key => $item) {
    if ($item['id'] == $id && $item['size'] == $size) {
        unset($_SESSION['cart'][$key]);
        break;
    }
}

// কার্ট অ্যারে রি-ইনডেক্স করা
$_SESSION['cart'] = array_values($_SESSION['cart']);

header("Location: cart.php");
exit;
?>
<?php
session_start();

$id = $_GET['id'];
$size = $_GET['size'];

foreach ($_SESSION['cart'] as $key => $item) {
    if ($item['id'] == $id && $item['size'] == $size) {
        unset($_SESSION['cart'][$key]);
        break;
    }
}

// কার্ট অ্যারে রি-ইনডেক্স করা
$_SESSION['cart'] = array_values($_SESSION['cart']);

header("Location: cart.php");
exit;
?>
