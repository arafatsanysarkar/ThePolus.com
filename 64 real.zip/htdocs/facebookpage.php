<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>আমাদের ফেসবুক পেইজসমূহ</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f0f2f5;
      margin: 0;
      padding: 0;
    }

    header {
      background-color: #1877f2;
      color: white;
      text-align: center;
      padding: 30px 10px;
      font-size: 26px;
      font-weight: bold;
      letter-spacing: 1px;
    }

    .container {
      max-width: 800px;
      margin: 30px auto;
      padding: 0 20px;
    }

    .card {
      background: white;
      border-radius: 12px;
      padding: 25px;
      margin-bottom: 20px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      transition: transform 0.2s ease;
    }

    .card:hover {
      transform: scale(1.02);
    }

    .title {
      font-size: 22px;
      font-weight: bold;
      margin-bottom: 10px;
      color: #333;
    }

    .description {
      font-size: 16px;
      color: #555;
      margin-bottom: 15px;
    }

    .link-btn {
      display: inline-block;
      padding: 10px 20px;
      background-color: #1877f2;
      color: white;
      text-decoration: none;
      border-radius: 8px;
      font-weight: bold;
    }

    .link-btn:hover {
      background-color: #145fd1;
    }

    footer {
      text-align: center;
      padding: 20px;
      color: #777;
    }
  </style>
</head>
<body>

  <header>আমাদের ফেসবুক পেইজসমূহ</header>

  <div class="container">

     

     <div class="card">
      <div class="title">The Polus</div>
      <div class="description">আমাদের ফেসবুক পেইজসমূহ The Polus</div>
      <a class="link-btn" href="https://www.facebook.com/profile.php?id=61573714334614" target="_blank">পেইজ দেখুন</a>
    </div>
     

    <div class="card">
      <div class="title">স্পর্শ</div>
      <div class="description">স্পর্শ ব্রান্ড এর ফেসবুক পেইজ</div>
      <a class="link-btn" href="https://www.facebook.com/profile.php?id=61557392183602" target="_blank">পেইজ দেখুন</a>
    </div>

    <div class="card">
      <div class="title">Nijerhut.com</div>
      <div class="description">Nijerhut.com ব্রান্ড এর ফেসবুক পেইজ</div>
      <a class="link-btn" href="https://www.facebook.com/profile.php?id=100063803912550" target="_blank">পেইজ দেখুন</a>
    </div>

    <div class="card">
      <div class="title">Perfect Fashion</div>
      <div class="description">Perfect Fashion ব্রান্ড এর ফেসবুক পেইজ</div>
      <a class="link-btn" href="https://www.facebook.com/perfectfashion7464/" target="_blank">পেইজ দেখুন</a>
    </div>



    <div class="card">
      <div class="title">RongRa - রংরা </div>
      <div class="description">RongRa - রংরা ব্রান্ড এর ফেসবুক পেইজ</div>
      <a class="link-btn" href="https://www.facebook.com/rongra77/" target="_blank">পেইজ দেখুন</a>
    </div>

    

  </div>

  <footer>© 2025 আমাদের ফেসবুক পেইজসমূহ</footer>

</body>
</html>
