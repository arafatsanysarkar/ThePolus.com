<?php
session_start();
include 'includes/db.php';

if (!isset($_GET['id'])) {
    echo "No product selected.";
    exit;
}

$product_id = $_GET['id'];

// Fetch product
$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->bind_param("i", $product_id);
$stmt->execute();
$result = $stmt->get_result();
$product = $result->fetch_assoc();

if (!$product) {
    echo "Product not found.";
    exit;
}

$main_image = $product['image'];
$other_images = !empty($product['other_images']) ? json_decode($product['other_images'], true) : [];

// Extract combo limit from description
$combo_limit = 0;
if (preg_match('/কম্বো অফার\s*(\d+)/u', $product['description'], $matches)) {
    $combo_limit = (int)$matches[1];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>View Combination - <?php echo htmlspecialchars($product['title']); ?></title>
  <style>
    body {
      font-family: Arial;
      background: #f9f9f9;
      margin: 0;
      padding: 20px;
    }
    .combo-container {
      display: flex;
      gap: 30px;
      background: white;
      padding: 25px;
      border-radius: 10px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    .main-image {
      flex: 1;
    }
    .main-image img {
      width: 100%;
      max-height: 400px;
      object-fit: contain;
      border-radius: 10px;
    }
    .thumbnails {
      display: flex;
      gap: 10px;
      margin-top: 10px;
      overflow-x: auto;
      width: 100%;
      padding-bottom: 10px;
    }
    .thumbnails label {
      display: flex;
      flex-direction: column;
      align-items: center;
      font-size: 14px;
    }
    .thumbnails img {
      width: 70px;
      height: 70px;
      object-fit: contain;
      border: 2px solid transparent;
      cursor: pointer;
      border-radius: 5px;
    }
    .thumbnails img:hover {
      border-color: #3498db;
    }
    .thumbnails-scroll {
      position: absolute;
      top: 50%;
      transform: translateY(-50%);
      font-size: 24px;
      color: #3498db;
      cursor: pointer;
    }
    .thumbnails-scroll-left {
      left: 10px;
    }
    .thumbnails-scroll-right {
      right: 10px;
    }
    .info {
      flex: 1;
    }
    .info h2 {
      margin-top: 0;
    }
    .info .price {
      font-size: 24px;
      color: #e74c3c;
      font-weight: bold;
    }
    .actions {
      margin-top: 20px;
    }
    .actions select, .actions input {
      padding: 10px;
      margin-bottom: 10px;
      width: 100%;
    }
    .actions button {
      width: 100%;
      padding: 12px;
      font-size: 16px;
      border: none;
      border-radius: 5px;
      background-color: #27ae60;
      color: white;
      cursor: pointer;
    }
    .actions button:hover {
      background-color: #219150;
    }
    .combo-note {
      background: #f0f0f0;
      padding: 10px;
      margin-bottom: 10px;
      border-left: 5px solid #27ae60;
    }
    .size-select {
      margin-top: 5px;
    }
  </style>
  <script>
    function changeMainImage(src) {
      document.getElementById("mainImage").src = src;
    }

    function handleComboLimit() {
      const comboLimit = <?php echo $combo_limit; ?>;
      const checkboxes = document.querySelectorAll('.combo-check');
      const checked = Array.from(checkboxes).filter(cb => cb.checked);
      if (comboLimit > 0 && checked.length > comboLimit) {
        alert(`আপনি সর্বোচ্চ ${comboLimit} টি প্রোডাক্ট সিলেক্ট করতে পারবেন।`);
        checked[checked.length - 1].checked = false;
      }
    }

    function scrollThumbnails(direction) {
      const thumbnails = document.querySelector('.thumbnails');
      const scrollAmount = 100; // Scroll by 100px each time
      thumbnails.scrollBy({
        left: direction * scrollAmount,
        behavior: 'smooth'
      });
    }
  </script>
</head>
<body>

<div class="combo-container">
  <div class="main-image">
    <img id="mainImage" src="uploads/<?php echo htmlspecialchars($main_image); ?>" alt="Main">
    <?php if (!empty($other_images)): ?>
    <div class="thumbnails">
      <form action="add_to_cart.php" method="POST">
        <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
        <input type="hidden" name="product_code" value="<?php echo htmlspecialchars($product['product_code']); ?>">

        <?php foreach ($other_images as $index => $img): ?>
          <label>
            <input type="checkbox" class="combo-check" name="combo_images[<?php echo $index; ?>][image]" value="<?php echo htmlspecialchars($img); ?>" onchange="handleComboLimit()" />
            <img src="uploads/<?php echo htmlspecialchars($img); ?>" onclick="changeMainImage(this.src)">
            <select class="size-select" name="combo_images[<?php echo $index; ?>][size]">
              <option value="">Size</option>
              <option value="S">S</option>
              <option value="M">M</option>
              <option value="L">L</option>
              <option value="XL">XL</option>
            </select>
          </label>
        <?php endforeach; ?>
    </div>
    <div class="thumbnails-scroll thumbnails-scroll-left" onclick="scrollThumbnails(-1)">◀</div>
    <div class="thumbnails-scroll thumbnails-scroll-right" onclick="scrollThumbnails(1)">▶</div>
    </form>
    <?php endif; ?>
  </div>

  <div class="info">
    <h2><?php echo htmlspecialchars($product['title']); ?></h2>
    <p><?php echo nl2br(htmlspecialchars($product['description'])); ?></p>
    <p class="price">৳<?php echo number_format($product['price']); ?> BDT</p>

    <?php if ($combo_limit > 0): ?>
      <div class="combo-note">
        ✅ এই কম্বো অফারে সর্বোচ্চ <strong><?php echo $combo_limit; ?></strong> টি প্রোডাক্ট সিলেক্ট করা যাবে।
      </div>
    <?php endif; ?>

    <div class="actions">
      <label>পরিমাণ:</label>
      <input type="number" name="quantity" min="1" value="1" required>
      <button type="submit" name="add_to_cart">Add to Cart</button>
    </div>
    </form>
  </div>
</div>

</body>
</html>
