<?php
session_start();
include 'includes/db.php';
include('includes/functions.php');

$cart_count = 0;
if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $cart_count += isset($item['quantity']) ? (int)$item['quantity'] : 1;
    }
}


if (isset($_GET['id'])) {
    $product_id = $_GET['id'];

    // ক্লিক কাউন্ট আপডেট
    $update_stmt = $conn->prepare("UPDATE products SET click_count = click_count + 1 WHERE id = ?");
    $update_stmt->bind_param("i", $product_id);
    $update_stmt->execute();

    // পণ্য লোড
    $query = "SELECT * FROM products WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();

    if (!$product) {
        echo "Product not found.";
        exit;
    }

    $other_images = [];
    if (!empty($product['other_images'])) {
        $other_images = json_decode($product['other_images'], true);
    }

    // Seller ID
    $seller_id = $product['seller_id'];

    // Seller এর অন্য সব প্রোডাক্ট লোড করো (এই প্রোডাক্ট বাদে)
    $related_query = "SELECT * FROM products WHERE seller_id = ? AND id != ? ORDER BY id DESC";
    $related_stmt = $conn->prepare($related_query);
    $related_stmt->bind_param("ii", $seller_id, $product_id);
    $related_stmt->execute();
    $related_result = $related_stmt->get_result();
    $related_products = $related_result->fetch_all(MYSQLI_ASSOC);

} else {
    echo "No product selected.";
    exit;
}


// Seller ID
$seller_id = $product['seller_id'];


// Seller info from users table
$seller_info_query = "SELECT brand_name, email, brand_image FROM users WHERE id = ?";
$seller_info_stmt = $conn->prepare($seller_info_query);
$seller_info_stmt->bind_param("i", $seller_id);
$seller_info_stmt->execute();
$seller_info_result = $seller_info_stmt->get_result();
$seller_info = $seller_info_result->fetch_assoc();


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

  <title><?php echo htmlspecialchars($product['title']); ?> | The Polus</title>

<meta name="description" content="<?php echo substr(strip_tags($product['description']), 0, 150); ?>">
<meta name="keywords" content="<?php echo htmlspecialchars($product['title']); ?>, buy <?php echo htmlspecialchars($product['title']); ?>, online shopping">
<meta name="author" content="The Polus">
<meta property="og:title" content="<?php echo htmlspecialchars($product['title']); ?> | The Polus">
<meta property="og:description" content="<?php echo substr(strip_tags($product['description']), 0, 150); ?>">
<meta property="og:image" content="https://thepolus.free.nf/uploads/<?php echo $product['image']; ?>">
<meta property="og:url" content="https://thepolus.free.nf/product.php?id=<?php echo $product['id']; ?>">
<meta name="twitter:card" content="summary_large_image">

<!-- Favicon -->
    <link rel="icon" type="image/png" href="image/logofav.png">



    <script type="application/ld+json">
  {
    "@context": "https://schema.org/",
    "@type": "Product",
    "name": "<?php echo htmlspecialchars($product['title']); ?>",
    "image": [
      "https://thepolus.free.nf/uploads/<?php echo $product['image']; ?>"
    ],
    "description": "<?php echo substr(strip_tags($product['description']), 0, 200); ?>",
    "sku": "<?php echo $product['id']; ?>",
    "offers": {
      "@type": "Offer",
      "priceCurrency": "BDT",
      "price": "<?php echo $product['price']; ?>",
      "availability": "https://schema.org/InStock",
      "url": "https://thepolus.free.nf/product.php?id=<?php echo $product['id']; ?>"
    }
  }
  </script><script type="application/ld+json">
  {
    "@context": "https://schema.org/",
    "@type": "Product",
    "name": "<?php echo htmlspecialchars($product['title']); ?>",
    "image": [
      "https://thepolus.free.nf/uploads/<?php echo $product['image']; ?>"
    ],
    "description": "<?php echo substr(strip_tags($product['description']), 0, 200); ?>",
    "sku": "<?php echo $product['id']; ?>",
    "offers": {
      "@type": "Offer",
      "priceCurrency": "BDT",
      "price": "<?php echo $product['price']; ?>",
      "availability": "https://schema.org/InStock",
      "url": "https://thepolus.free.nf/product.php?id=<?php echo $product['id']; ?>"
    }
  }
  </script>


  <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [{
    "@type": "ListItem",
    "position": 1,
    "name": "Home",
    "item": "https://thepolus.free.nf"
  },{
    "@type": "ListItem",
    "position": 2,
    "name": "Contact",
    "item": "https://thepolus.free.nf/contact.php"
  },{
    "@type": "ListItem",
    "position": 3,
    "name": "<?php echo htmlspecialchars($product['title']); ?>",
    "item": "https://thepolus.free.nf/product.php?id=<?php echo $product['id']; ?>"
  }]
}
</script>



  <link rel="stylesheet" href="assets/navstyles.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="https://kit.fontawesome.com/c9847c48a6.js" crossorigin="anonymous"></script>
  <style>
    

    .product-page {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 30px;
      margin: 30px auto;
      padding: 25px;
      max-width: 1200px;
      background-color: #ffffff;
      border-radius: 15px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
    }

    .main-image img {
  width: 100%;
  height: 360px; /* নির্দিষ্ট হাইট সেট করুন */
  object-fit: contain; /* ছবির সাইজ ঠিক রাখতে এই প্রপার্টি ব্যবহার করুন */
  border-radius: 10px;
  background-color: #fafafa;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}


    .thumbnail-wrapper {
      display: flex;
      align-items: center;
      margin-top: 10px;
    }

    .scroll-btn {
      background-color: #3498db;
      color: #fff;
      border: none;
      padding: 8px 12px;
      font-size: 18px;
      cursor: pointer;
      border-radius: 5px;
      margin: 0 5px;
    }

    .scroll-btn:hover {
      background-color: #2980b9;
    }

    .thumbnail-container {
      display: flex;
      gap: 10px;
      overflow-x: auto;
      max-width: calc(75px * 4 + 10px * 3);
      scrollbar-width: none;
    }

    .thumbnail-container::-webkit-scrollbar {
      display: none;
    }

    .thumbnail-container img {
      width: 75px;
      height: 75px;
      object-fit: contain;
      border-radius: 5px;
      cursor: pointer;
      background-color: #fff;
      transition: transform 0.3s ease;
    }

    .thumbnail-container img:hover {
      transform: scale(1.1);
    }

    .product-details h1 {
      font-size: 26px;
      color: #2c3e50;
    }

    .description {
      font-size: 15px;
      color: #555;
      line-height: 1.6;
      margin: 15px 0;
      max-height: 250px;
      overflow-y: auto;
    }

    .price {
      font-size: 24px;
      font-weight: bold;
      color: #e74c3c;
    }

    .size-select,
    .quantity-select {
      font-size: 16px;
      padding: 8px;
      margin-bottom: 15px;
      border-radius: 5px;
      border: 1px solid #ccc;
      width: 100%;
      max-width: 220px;
    }

    .product-actions button {
      padding: 12px 20px;
      font-size: 16px;
      border: none;
      border-radius: 8px;
      color: #fff;
      cursor: pointer;
      transition: background-color 0.3s ease;
      width: 100%;
      max-width: 100%;
    }

    .add-to-cart {
      background-color: #2ecc71;
      margin-top: 15px;
    }

    .add-to-cart:hover {
      background-color: #27ae60;
    }

    .order-now {
      background-color: #e67e22;
    }

    .order-now:hover {
      background-color: #d35400;
    }

    .save-product {
      background-color: #9b59b6;
    }

    .save-product:hover {
      background-color: #8e44ad;
    }


    .more-from-heading {
    text-align: center;
    font-size: 1.6rem;
    color: #2c3e50;
    margin: 40px 0 30px;
    font-weight: 600;
}

.more-from-heading .brand-link {
    display: inline-block;
    margin-left: 8px;
    color: #2a9d8f; /* আপনার চাহিদা অনুযায়ী কালার */
    font-weight: 700;
    text-decoration: none;
    padding: 4px 10px;
    border-radius: 6px;
    transition: all 0.3s ease;
}

.more-from-heading .brand-link:hover {
    background-color: #dffaf6; /* হালকা সবুজ/নীল ব্যাকগ্রাউন্ড */
    color: #1e7366; /* হোভার করলে গাঢ় কালার */
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}




  /* মোবাইল ডিভাইসের জন্য ফন্ট সাইজ কমানো */
  @media (max-width: 600px) {
    .more-from-heading {
      font-size: 20px;  /* মোবাইলে ছোট সাইজ */
    }
  }


    @media (max-width: 768px) {
      .product-page {
        padding: 15px;
        margin: 15px;
      }

      .product-details h1 {
        font-size: 22px;
      }

      .price {
        font-size: 20px;
      }
    }
  </style>
</head>
<body>

<section id="header">
  <a href="#"><img src="image/logo.png" class="logo" alt=""></a>
  <div>
    <ul id="navbar">
      <li><a href="../index.php">Home</a></li>
      <li><a href="#about.html">Shop</a></li>
      <li><a href="#contact.html">Contact</a></li>
      
      <?php if (isLoggedIn()): ?>
                <?php if (isSeller()): ?>
                    <li><a href="seller/dashboard.php">Profile</a></li>
                <?php elseif (isCustomer()): ?>
                    <li><a href="customer/dashboard.php">Profile</a></li>
                <?php endif; ?>
            <?php else: ?>
                <li><a href="login.php">Log in</a></li>
            <?php endif; ?>

      <li><a class="active" href="#">Product Page</a></li>

      <li id="lg-bag">
        <a href="cart.php">
          <i class="cart">🛒</i>
          <?php if ($cart_count > 0): ?>
            <span class="cart-badge"><?php echo $cart_count; ?></span>
          <?php endif; ?>
        </a>
      </li>
      <a href="#" id="close"><i class="fa-solid fa-xmark"></i></a>
    </ul>
  </div>
  <div id="mobile">
    <a href="cart.php" class="mobile-cart">
      <i class="cart">🛒</i>
      <?php if ($cart_count > 0): ?>
        <span class="cart-badge"><?php echo $cart_count; ?></span>
      <?php endif; ?>
    </a>
    <i id="bar" class="fas fa-outdent"></i>
  </div>
</section>

<div class="product-page">
  <div class="product-images">
    <div class="main-image">
      <img id="mainImage" src="uploads/<?php echo $product['image']; ?>" alt="Main Product Image" />
    </div>
    <?php if (!empty($other_images)): ?>
    <div class="thumbnail-wrapper">
      <button class="scroll-btn" onclick="scrollThumbnails(-100)">◀</button>
      <div class="thumbnail-container" id="thumbnailContainer">
        <?php foreach ($other_images as $img): ?>
          <img src="uploads/<?php echo htmlspecialchars($img); ?>" onclick="changeImage('uploads/<?php echo htmlspecialchars($img); ?>')" />
        <?php endforeach; ?>
      </div>
      <button class="scroll-btn" onclick="scrollThumbnails(100)">▶</button>
    </div>
    <?php endif; ?>
  </div>

  <div class="product-details">
    <h1><?php echo htmlspecialchars($product['title']); ?></h1>
    <div class="description"><?php echo nl2br(htmlspecialchars($product['description'])); ?></div>
  </div>

  <div class="product-summary">
    <p class="price">৳<?php echo number_format($product['price']); ?> BDT</p>


    <label for="size">সাইজ সিলেক্ট করুন:</label>
<select id="size" class="size-select">

  <?php
    $title = strtolower($product['title']); // পণ্যের টাইটেল ছোট হাতের অক্ষরে নিয়ে আসুন

    // সাইজের অপশন নির্ধারণ
    if (
        strpos($title, 'shirt') !== false ||
        strpos($title, 't-shirt') !== false ||
        strpos($title, 'শার্ট') !== false ||
        strpos($title, 'টি-শার্ট') !== false
    ) {
        // T-Shirt, Shirt অথবা shirt থাকলে S, M, L, XL, XXL সাইজ দেখাবে
        echo '<option value="S">Small</option>';
        echo '<option value="M">Medium</option>';
        echo '<option value="L">Large</option>';
        echo '<option value="XL">X-Large</option>';
        echo '<option value="XXL">XX-Large</option>';
    } elseif (strpos($title, 'pant') !== false) {
        // Pant থাকলে 30, 31, 32, 33, 34, 35, 36, 37 সাইজ দেখাবে
        echo '<option value="30">30</option>';
        echo '<option value="31">31</option>';
        echo '<option value="32">32</option>';
        echo '<option value="33">33</option>';
        echo '<option value="34">34</option>';
        echo '<option value="35">35</option>';
        echo '<option value="36">36</option>';
        echo '<option value="37">37</option>';
    } else {
        // অন্য কোনো সাইজ কেসের জন্য ডিফল্ট সাইজ
        echo '<option value="no-need">সিলেক্ট করতে হবে না।</option>';
    }
?>

</select>


    <br><br>

    <label for="quantity">অর্ডারের পরিমাণ:</label> <br>
    <select id="quantity" class="quantity-select">
      <?php for ($i = 1; $i <= 10; $i++): ?>
        <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
      <?php endfor; ?>
    </select>

    <div class="product-actions">
      <button class="add-to-cart" onclick="addToCart(<?php echo $product['id']; ?>)"><i class="fa-solid fa-bag-shopping"></i>   কার্টে যোগ করুন</button>
      <div style="display: flex; gap: 10px; margin-top: 10px;">
        <a href="javascript:void(0)" onclick="orderNow(<?php echo $product['id']; ?>)" style="flex: 1;">
          <button class="order-now">🛒 অর্ডার নাও</button>
        </a>
        <button onclick="saveProduct(<?php echo $product['id']; ?>)" class="save-product" style="flex: 1;">💾 সেভ করুন</button>
      </div>
    </div>
  </div>
</div>






<?php if ($seller_info): ?>
  <div style="margin-top: 30px; padding: 20px; background-color: #f8f9fa; border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); max-width: 800px; margin-left:auto; margin-right:auto;">
    
    <div style="display: flex; align-items: center; gap: 20px;">
      <?php if (!empty($seller_info['brand_image'])): ?>
        <img src="uploads/<?php echo htmlspecialchars($seller_info['brand_image']); ?>" alt="Brand Logo" style="width: 80px; height: 80px; object-fit: contain; border-radius: 10px; background-color: #fff; border: 1px solid #ddd;" />
      <?php endif; ?>
      <div>

        <p style="margin: 0; font-size: 20px; color: #2a9d8f; font-weight: bold;">
  <?php echo htmlspecialchars($seller_info['brand_name']); ?>
</p>

        <p style="margin: 0;"><strong>Email:</strong> <?php echo htmlspecialchars($seller_info['email']); ?></p>
      </div>
    </div>
  </div>
<?php endif; ?>







<div style="max-width:1200px;margin:0 auto;padding:20px">

  <h2 class="more-from-heading">
  More from 
  <a href="seller_products.php?seller_id=<?php echo $seller_id; ?>" class="brand-link">
    <?php echo htmlspecialchars($seller_info['brand_name']); ?>
  </a>
</h2>


  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:20px">
    <?php foreach ($related_products as $rel): ?>
      <div style="border:1px solid #ddd;border-radius:10px;padding:10px;text-align:center;background:#fff;box-shadow:0 2px 5px rgba(0,0,0,0.05)">
        <a href="product.php?id=<?php echo $rel['id']; ?>" style="text-decoration:none;color:inherit">
          <img src="uploads/<?php echo $rel['image']; ?>" alt="<?php echo htmlspecialchars($rel['title']); ?>" style="width:100%;height:180px;object-fit:contain;border-radius:10px;margin-bottom:10px">
          <h4 style="font-size:18px;font-weight:600;color:#34495e;overflow:hidden;white-space:nowrap;text-overflow:ellipsis"><?php echo htmlspecialchars($rel['title']); ?></h4>
          <p style="color:#e74c3c;font-weight:bold;margin:10px 0">৳ <?php echo number_format($rel['price']); ?></p>
        </a>
      </div>
    <?php endforeach; ?>
  </div>
</div>


<script>
let bar = document.getElementById('bar');
let nav = document.getElementById('navbar');
let mobile = document.getElementById('mobile');
let close = document.getElementById('close');

if (bar) {
    bar.addEventListener('click', () => {
        nav.classList.add('active');
        mobile.classList.add('hide'); // মোবাইল cart & bar আইকন হাইড করো
    });
}

if (close) {
    close.addEventListener('click', () => {
        nav.classList.remove('active');
        mobile.classList.remove('hide'); // আবার দেখাও
    });
}


function changeImage(imageSrc) {
  document.getElementById("mainImage").src = imageSrc;
}

function scrollThumbnails(amount) {
  document.getElementById("thumbnailContainer").scrollBy({
    left: amount,
    behavior: "smooth"
  });
}

function addToCart(productId) {
  const selectedSize = document.getElementById("size").value;
  const selectedQuantity = document.getElementById("quantity").value;
  const xhr = new XMLHttpRequest();
  xhr.open("GET", "add_to_cart.php?id=" + productId + "&size=" + selectedSize + "&quantity=" + selectedQuantity, true);
  xhr.onload = function () {
    if (xhr.status === 200) {
      showAddToCartPopup();
      updateCartNotification();
    }
  };
  xhr.send();
}

function orderNow(productId) {
  const selectedSize = document.getElementById("size").value;
  const selectedQuantity = document.getElementById("quantity").value;

  const xhr = new XMLHttpRequest();
  xhr.open("GET", "add_to_cart.php?id=" + productId + "&size=" + selectedSize + "&quantity=" + selectedQuantity, true);
  xhr.onload = function () {
    if (xhr.status === 200) {
      showAddToCartPopup();
      setTimeout(() => {
        window.location.href = "cart.php";
      }, 1000);
    }
  };
  xhr.send();
}

function showAddToCartPopup() {
  Swal.fire({
    title: 'পণ্যটি কার্টে যোগ হয়েছে!',
    icon: 'success',
    showConfirmButton: false,
    timer: 1000,
    timerProgressBar: true  // এটা যোগ করলে নিচের টাইম ফ্লো দেখা যাবে
  });
}


function updateCartNotification() {
  const xhr = new XMLHttpRequest();
  xhr.open("GET", "get_cart_count.php", true);
  xhr.onload = function () {
    if (xhr.status === 200) {
      const cartCount = xhr.responseText;
      let cartNotification = document.querySelector('.cart-badge');

      // মোবাইল এবং পিসি উভয়ের জন্য সঠিক cart icon সিলেক্ট করো
      let cartIcon = document.querySelector('#lg-bag a') || document.querySelector('.mobile-cart-icon');

      // যদি badge না থাকে, তাহলে তৈরি করো এবং append করো
      if (!cartNotification && cartIcon) {
        cartNotification = document.createElement('span');
        cartNotification.classList.add('cart-badge');
        cartIcon.appendChild(cartNotification);
      }

      if (cartNotification) {
        if (cartCount > 0) {
          cartNotification.textContent = cartCount;
          cartNotification.style.display = 'inline-block';
        } else {
          cartNotification.style.display = 'none';
        }
      }
    }
  };
  xhr.send();
}

// ensure DOM is ready
document.addEventListener("DOMContentLoaded", function () {
  updateCartNotification();
});


</script>



<script>
function saveProduct(productId) {
  fetch('save_product.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: 'product_id=' + productId
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      Swal.fire({
        icon: 'success',
        title: 'সেভ করা হয়েছে!',
        text: data.message
      });
    } else {
      Swal.fire({
        icon: 'error',
        title: 'ত্রুটি!',
        text: data.message
      });
    }
  });
}
</script>





</body>
</html>