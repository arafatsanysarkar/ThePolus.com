<?php
session_start();

// Database connection
include('includes/db.php');

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];  // Assuming the user ID is stored in session

    // Get the product ID from the URL
    $product_id = $_GET['id'];

    // Check if the user has already viewed this product
    $sql = "SELECT viewed_products FROM users WHERE id = '$user_id'";
    $result = $conn->query($sql);
    $user_data = $result->fetch_assoc();
    $viewed_products = json_decode($user_data['viewed_products'], true);

    // If the product hasn't been viewed by the user yet, increase the click count
    if (!in_array($product_id, $viewed_products)) {
        // Increment the click count for the product
        $conn->query("UPDATE products SET click_count = click_count + 1 WHERE id = '$product_id'");

        // Add this product to the list of viewed products for the user
        $viewed_products[] = $product_id;
        $viewed_products_json = json_encode($viewed_products);
        $conn->query("UPDATE users SET viewed_products = '$viewed_products_json' WHERE id = '$user_id'");
    }
}

// Redirect to the product page after click is registered
header("Location: product.php?id=$product_id");
exit();
?>
